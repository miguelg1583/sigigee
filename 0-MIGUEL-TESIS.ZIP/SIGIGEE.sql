-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-05-2017 a las 08:45:29
-- Versión del servidor: 10.0.17-MariaDB
-- Versión de PHP: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sigigee`
--
CREATE DATABASE IF NOT EXISTS `sigigee` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `sigigee`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignacion_comb`
--

CREATE TABLE `asignacion_comb` (
  `id` int(11) NOT NULL,
  `provincia_id` int(11) DEFAULT NULL,
  `entidad_id` int(11) DEFAULT NULL,
  `gee_id` int(11) DEFAULT NULL,
  `tipo_distribucion_id` int(11) DEFAULT NULL,
  `fechaSolic` date NOT NULL,
  `combustible` double NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `asignacion_comb`
--

INSERT INTO `asignacion_comb` (`id`, `provincia_id`, `entidad_id`, `gee_id`, `tipo_distribucion_id`, `fechaSolic`, `combustible`, `deleted_at`) VALUES
(4, 4, 17, 17, 2, '2017-02-01', 404.1852, NULL),
(5, 4, 9, 9, 2, '2017-02-02', 380.4096, NULL),
(6, 4, 4, 4, 1, '2017-02-02', 178.317, NULL),
(7, 4, 5, 5, 2, '2017-02-04', 427.9608, NULL),
(8, 4, 1, 1, 1, '2017-02-03', 380.4096, NULL),
(9, 4, 6, 6, 2, '2017-02-04', 427.9608, NULL),
(10, 4, 7, 7, 2, '2017-01-01', 11293410, NULL),
(11, 4, 8, 8, 1, '2016-12-21', 1427130.39, NULL),
(12, 4, 10, 10, 1, '2015-02-03', 356.634, NULL),
(13, 4, 11, 11, 2, '2014-10-07', 1426.536, NULL),
(14, 4, 12, 12, 1, '2017-01-05', 748.9314, NULL),
(15, 4, 13, 13, 1, '2014-04-22', 2805.5208, NULL),
(16, 4, 14, 14, 1, '2015-06-24', 4172.6178, NULL),
(17, 4, 15, 15, 2, '2016-02-07', 6062.778, NULL),
(18, 4, 16, 16, 2, '2016-08-15', 4398.486, NULL),
(19, 4, 4, 19, 1, '2017-02-06', 2496.438, NULL),
(20, 4, 14, 20, 2, '2017-02-07', 297.195, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `certif_operacion`
--

CREATE TABLE `certif_operacion` (
  `id` int(11) NOT NULL,
  `gee_id` int(11) DEFAULT NULL,
  `municipio_id` int(11) DEFAULT NULL,
  `centro_id` int(11) DEFAULT NULL,
  `marca_id` int(11) DEFAULT NULL,
  `kva_voltaje_salida_id` int(11) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `operacSinCarga` int(11) DEFAULT NULL,
  `operacConCarga` int(11) DEFAULT NULL,
  `horasSinCarga` double DEFAULT NULL,
  `horasConCarga` double DEFAULT NULL,
  `energiaGenerada` double DEFAULT NULL,
  `combustSinCarga` double DEFAULT NULL,
  `combustConCarga` double DEFAULT NULL,
  `mes` int(11) DEFAULT NULL,
  `anno` int(11) DEFAULT NULL,
  `estado_certificacion_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `certif_operacion`
--

INSERT INTO `certif_operacion` (`id`, `gee_id`, `municipio_id`, `centro_id`, `marca_id`, `kva_voltaje_salida_id`, `deleted_at`, `operacSinCarga`, `operacConCarga`, `horasSinCarga`, `horasConCarga`, `energiaGenerada`, `combustSinCarga`, `combustConCarga`, `mes`, `anno`, `estado_certificacion_id`) VALUES
(21, 1, 9, 1, 13, 8, NULL, NULL, 1, NULL, 0.5, 12, NULL, 4, 2, 2017, 2),
(22, 1, 1, 1, 1, 1, '2017-02-18 10:53:04', 1, 1, 3, 5, 11.3, 22, 30, 5, 2016, 2),
(23, 7, 1, 5, 6, 6, '2017-02-18 10:53:04', 1, NULL, 10, NULL, 23.1, 35, NULL, 12, 2016, 1),
(24, 8, 1, 10, 3, 8, '2017-02-18 10:53:04', NULL, 2, NULL, 9, 41, NULL, 120, 2, 2017, 2),
(25, 10, 7, 4, 8, 7, '2017-02-18 10:53:04', 3, 1, 5, 12, 51.32, 15, 33, 11, 2016, 2),
(26, 7, 4, 5, 7, 6, NULL, 1, 3, 2, 4, 33.1, 63, 20, 3, 2016, 2),
(27, 7, 10, 7, 10, 7, NULL, NULL, 1, NULL, 2, 55.3, NULL, 18, 1, 2017, NULL),
(28, 4, 9, 4, 12, 3, NULL, 1, 0, 3, 0, NULL, 26.7, 0, 2, 2017, NULL),
(29, 7, 10, 7, 10, 7, NULL, NULL, 1, NULL, 403, 52, NULL, 3627, 8, 2015, NULL),
(30, 6, 6, 6, 7, 6, NULL, 2, 1, 3, 5, 33.2, 56, 26, 5, 2016, 1),
(31, 12, 8, 8, 8, 2, NULL, 2, NULL, 10, NULL, 33, 120, NULL, 11, 2016, 2),
(32, 20, 10, 14, 13, 8, NULL, NULL, 1, NULL, 10, 120, NULL, 83, 2, 2013, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `concepto_aprob_comb`
--

CREATE TABLE `concepto_aprob_comb` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `concepto_aprob_comb`
--

INSERT INTO `concepto_aprob_comb` (`id`, `nombre`) VALUES
(1, 'Llenado Inicial'),
(2, 'Por Operaciones'),
(4, 'Por Orden UNE'),
(3, 'Prueba de Disponibilidad');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entidad`
--

CREATE TABLE `entidad` (
  `id` int(11) NOT NULL,
  `entidad_superior_id` int(11) DEFAULT NULL,
  `ministerio_id` int(11) DEFAULT NULL,
  `municipio_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `provincia_id` int(11) DEFAULT NULL,
  `moneda_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `entidad`
--

INSERT INTO `entidad` (`id`, `entidad_superior_id`, `ministerio_id`, `municipio_id`, `nombre`, `deleted_at`, `direccion`, `provincia_id`, `moneda_id`) VALUES
(1, 12, 21, 9, 'CUBANACAN', NULL, '146A Nº907 e/ 9na Y 9naA', 4, 1),
(2, NULL, 23, 11, 'BANCO METROPOLITANO DIRECCION DE SERVICIOS GENERALES', '2017-02-13 08:30:05', 'VELAZQUEZ s/n  FABRICA Y REFORMA LUYANO', 4, 2),
(3, NULL, 20, 8, 'AEROPUERTO JOSE MARTI TERMINAL 1', '0000-00-00 00:00:00', 'VAN TROI y FINAL', 4, 1),
(4, NULL, 5, 9, 'PALMARES RESTAURANTES', NULL, '13Nº18006 e/ 5ta y 184 Siboney', 4, 2),
(5, NULL, 19, 8, 'CARDIOCENTRO WILLIAM SOLER', NULL, 'Calle Perla y 100', 4, 2),
(6, NULL, 19, 10, 'CLINICA CIRA GARCIA', NULL, 'Calle 41 esq 20', 4, 2),
(7, NULL, 5, 10, 'COPPELIA', NULL, 'CALLE 10 Nº 506 e/ 5ta Y 31', 4, 1),
(8, NULL, 15, 9, 'DATYS', NULL, '1ra e/4 y 6', 4, 1),
(9, NULL, 10, 9, 'DIRECCION PROVINCIAL DE EDUCACION', NULL, 'CALLE 22 e/ 1ra Y 3ra', 4, 1),
(10, NULL, 5, 1, 'FRIGORIFICO CARLOS III', NULL, 'ESTRELLA 771 E/ ARBOL SECO Y RETIRO', 4, 1),
(11, NULL, 21, 9, 'HAVANATUR', NULL, 'Calle 2 e/. 1ra y 3ra', 4, 2),
(12, NULL, 15, 9, 'INMIGRACION Y EXTRANJERIA', NULL, '22 E/5TA AVE Y 3RA', 4, 2),
(13, NULL, 20, 10, 'SERVAC', NULL, '23 / P y Malecon', 4, 2),
(14, NULL, 13, 10, 'UM-9058', NULL, '36 entre 39 y Kholy', 4, 1),
(15, NULL, 11, 10, 'UNIVERSIDAD DE LA HABANA', NULL, 'L y 21', 4, 2),
(16, NULL, 2, 8, 'EMPRESA DE CAMIONES NARCISO LOPEZ ROSELLO', NULL, 'Wajay', 4, 1),
(17, 16, 2, 8, 'INSTITUTO DE DESARROLLO AUTOMOTOR', NULL, 'Van Troi', 4, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_aprobacion`
--

CREATE TABLE `estado_aprobacion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `estado_aprobacion`
--

INSERT INTO `estado_aprobacion` (`id`, `nombre`) VALUES
(2, 'No'),
(3, 'Pendiente'),
(1, 'Si');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_certificacion`
--

CREATE TABLE `estado_certificacion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `estado_certificacion`
--

INSERT INTO `estado_certificacion` (`id`, `nombre`) VALUES
(2, 'Certificado'),
(3, 'Descertificado'),
(1, 'Sin Certificar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_gee`
--

CREATE TABLE `estado_gee` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `estado_gee`
--

INSERT INTO `estado_gee` (`id`, `nombre`) VALUES
(3, 'Baja Cobertura'),
(4, 'Nivel Crítico'),
(1, 'Óptimo'),
(5, 'Sin Combustible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_operacion`
--

CREATE TABLE `estado_operacion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `estado_operacion`
--

INSERT INTO `estado_operacion` (`id`, `nombre`) VALUES
(3, 'Despreciada'),
(1, 'Sin Validar'),
(2, 'Validada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_tecnico`
--

CREATE TABLE `estado_tecnico` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `estado_tecnico`
--

INSERT INTO `estado_tecnico` (`id`, `nombre`) VALUES
(1, 'Correcto'),
(2, 'Defecto Técnico'),
(3, 'Instrumentos Defectuosos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `existencia_gee`
--

CREATE TABLE `existencia_gee` (
  `id` int(11) NOT NULL,
  `tipo_gee_id` int(11) DEFAULT NULL,
  `entidad_id` int(11) DEFAULT NULL,
  `noInventario` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaEntrada` date NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `indice_carga` double DEFAULT NULL,
  `indice_sin_carga` double DEFAULT NULL,
  `cant_comb` double DEFAULT NULL,
  `cobertura_horas` double DEFAULT NULL,
  `distribucion_id` int(11) DEFAULT NULL,
  `instrumentos` tinyint(1) NOT NULL,
  `tanque_propio` double DEFAULT NULL,
  `tanque_aux` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `existencia_gee`
--

INSERT INTO `existencia_gee` (`id`, `tipo_gee_id`, `entidad_id`, `noInventario`, `fechaEntrada`, `deleted_at`, `estado_id`, `indice_carga`, `indice_sin_carga`, `cant_comb`, `cobertura_horas`, `distribucion_id`, `instrumentos`, `tanque_propio`, `tanque_aux`) VALUES
(1, 4, 1, 'CH2176', '2017-01-06', NULL, 3, 8, 7.2, 376.41, 47.05, 1, 1, NULL, NULL),
(2, 1, 2, 'CH1899', '2017-01-06', '2017-02-13 08:30:05', NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(4, 5, 4, 'CH6221', '2017-01-06', NULL, 4, 9.8, 8.9, 151.617, 15.47, 1, 1, NULL, NULL),
(5, 4, 5, 'CH7556', '2017-01-06', NULL, 3, 10.25, 9, 427.961, 41.75, 2, 1, NULL, NULL),
(6, 1, 6, 'CH5410', '2017-01-06', NULL, 1, 5.6, 6.2, 427.96, 76.42, 2, 1, NULL, NULL),
(7, 1, 7, 'CH3356', '2017-01-06', NULL, 1, 9, 4.3, 11289765, 1254418.33, 2, 1, NULL, NULL),
(8, 3, 8, 'CH6217', '2017-01-06', NULL, 1, 5.6, 8, 1427130.39, 254844.71, 1, 1, NULL, NULL),
(9, 4, 9, 'CH3046', '2017-01-06', NULL, 1, 12, 6, 1234, 102.83, 2, 1, NULL, NULL),
(10, 4, 10, 'CH6390', '2017-01-06', NULL, 3, 7.5, 5.3, 356.63, 47.55, 1, 0, NULL, NULL),
(11, 1, 11, 'CH9135', '2017-01-06', NULL, 1, 8.5, 11, 1426.54, 167.83, 2, 0, NULL, NULL),
(12, 1, 12, 'CH6122', '2017-01-06', NULL, 1, 7, 2, 748.93, 106.99, 1, 0, NULL, NULL),
(13, 1, 13, 'CH9624', '2017-01-06', NULL, 1, 33, 21, 2805.52, 85.02, 1, 0, NULL, NULL),
(14, 2, 14, 'CH5082', '2017-01-06', NULL, 1, 23, 12, 4172.62, 181.42, 1, 0, NULL, NULL),
(15, 2, 15, 'CH4507', '2017-01-06', NULL, 1, 12, 7, 6062.78, 505.23, 2, 0, NULL, NULL),
(16, 1, 16, 'CH2848', '2017-01-06', NULL, 1, 30, 12, 4398.49, 146.62, 2, 0, NULL, NULL),
(17, 3, 17, 'CH7291', '2017-01-06', NULL, 4, 55, 30, 956.55, 17.39, 2, 0, NULL, NULL),
(19, 3, 4, 'CH9020', '2016-04-04', NULL, 3, 56, 45, 2496.44, 44.58, 1, 1, 1000, 2000),
(20, 4, 14, 'CH1903', '2012-02-09', NULL, 3, 8.3, 5.2, 214.2, 25.81, 2, 0, NULL, NULL),
(21, 1, 1, '123456', '2019-07-04', '2017-05-24 00:55:21', 5, 1, 1, NULL, 0, 1, 0, NULL, NULL),
(22, 1, 1, 'hkkhkh', '2017-04-06', '2017-04-06 14:46:00', 5, 100, NULL, NULL, 0, 1, 0, NULL, NULL),
(25, 1, 1, 'dgdfgfdgdfgg', '2017-05-24', '2017-05-24 00:55:21', 5, 12, 12, NULL, 0, 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fos_user_group`
--

CREATE TABLE `fos_user_group` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fos_user_user`
--

CREATE TABLE `fos_user_user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `locked` tinyint(1) NOT NULL,
  `expired` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `credentials_expired` tinyint(1) NOT NULL,
  `credentials_expire_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `date_of_birth` datetime DEFAULT NULL,
  `firstname` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `biography` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook_uid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook_data` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:json)',
  `twitter_uid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_data` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:json)',
  `gplus_uid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gplus_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gplus_data` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:json)',
  `token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `two_step_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `fos_user_user`
--

INSERT INTO `fos_user_user` (`id`, `username`, `username_canonical`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `locked`, `expired`, `expires_at`, `confirmation_token`, `password_requested_at`, `roles`, `credentials_expired`, `credentials_expire_at`, `created_at`, `updated_at`, `date_of_birth`, `firstname`, `lastname`, `website`, `biography`, `gender`, `locale`, `timezone`, `phone`, `facebook_uid`, `facebook_name`, `facebook_data`, `twitter_uid`, `twitter_name`, `twitter_data`, `gplus_uid`, `gplus_name`, `gplus_data`, `token`, `two_step_code`) VALUES
(1, 'admin', 'admin', 'admingee@eleclh.une.cu', 'admingee@eleclh.une.cu', 1, 'izhvx1bwnlcskkk04kkg4ook8wc8kso', '$2y$13$izhvx1bwnlcskkk04kkg4eevllu3FQauwyKmEi1Re595OHSXKIuPO', '2017-05-30 18:56:24', 0, 0, NULL, NULL, NULL, 'a:1:{i:0;s:16:"ROLE_SUPER_ADMIN";}', 0, NULL, '2017-01-08 13:09:59', '2017-05-30 18:56:24', NULL, NULL, NULL, NULL, NULL, 'u', NULL, NULL, NULL, NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL),
(14, 'procesadorDatos', 'procesadordatos', 'procesadorDatos@eleclh.une.cu', 'procesadordatos@eleclh.une.cu', 1, 'hz5x8x798tckswoogswwwk4g0g4gcgw', '$2y$13$hz5x8x798tckswoogswwwerLJpoKoylHuF.PHmJV7KQyPOvvt/jSC', '2017-02-18 12:09:24', 0, 0, NULL, NULL, NULL, 'a:2:{i:0;s:21:"ROLE_PROCESADOR_DATOS";i:1;s:10:"ROLE_ADMIN";}', 0, NULL, '2017-02-18 11:27:53', '2017-02-18 12:09:24', NULL, NULL, NULL, NULL, NULL, 'u', NULL, NULL, NULL, NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL),
(15, 'operadora', 'operadora', 'operadora@eleclh.une.cu', 'operadora@eleclh.une.cu', 1, '3qgpu47yzgcg88s4ckkgcsc0go0kkgg', '$2y$13$3qgpu47yzgcg88s4ckkgceF/APfx6bLEdxM8IpZmjIBDb2Z9Q3iC.', NULL, 0, 0, NULL, NULL, NULL, 'a:2:{i:0;s:10:"ROLE_ADMIN";i:1;s:14:"ROLE_OPERADORA";}', 0, NULL, '2017-02-18 12:11:45', '2017-02-18 12:11:45', NULL, NULL, NULL, NULL, NULL, 'u', NULL, NULL, NULL, NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL),
(17, 'validador', 'validador', 'validador@eleclh.une.cu', 'validador@eleclh.une.cu', 1, 'kayc6e59n5s0okgo4o84w840o0o8scw', '$2y$13$kayc6e59n5s0okgo4o84wu0a8Cw40x8G5EzMH2Z2y5z17BSxzsnUa', NULL, 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL, '2017-02-18 12:21:44', '2017-05-03 11:56:31', NULL, NULL, NULL, NULL, NULL, 'u', NULL, NULL, NULL, NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL),
(19, 'espComb', 'espcomb', 'espComb@eleclh.une.cu', 'espcomb@eleclh.une.cu', 1, 'h934ihb4ehsk404848skscc48co44k4', '$2y$13$h934ihb4ehsk404848sksOtor5PSGOOaBgVX/NocIw9TSUD7chISa', NULL, 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL, '2017-02-18 12:23:45', '2017-02-18 12:23:45', NULL, NULL, NULL, NULL, NULL, 'u', NULL, NULL, NULL, NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL),
(20, 'espPrinc', 'espprinc', 'espPric@eleclh.une.cu', 'esppric@eleclh.une.cu', 1, 'n85ojw874sg00o8oss0ckos4sow0wc8', '$2y$13$n85ojw874sg00o8oss0cke4gd7o.DGaCsrn6tSKIvHYNpI1Lznwfm', NULL, 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL, '2017-02-18 12:24:18', '2017-02-18 12:24:18', NULL, NULL, NULL, NULL, NULL, 'u', NULL, NULL, NULL, NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL, 'null', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fos_user_user_group`
--

CREATE TABLE `fos_user_user_group` (
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ministerio`
--

CREATE TABLE `ministerio` (
  `id` int(11) NOT NULL,
  `siglas` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `ministerio`
--

INSERT INTO `ministerio` (`id`, `siglas`, `nombre`, `deleted_at`) VALUES
(1, 'MINEM', 'Ministerio de Energia y Minas', NULL),
(2, 'MINDUS', 'Ministerio de Industrias', NULL),
(3, 'MINAG', 'Ministerio de la Agricultura', NULL),
(4, 'CITMA', 'Ministerio de Ciencia, Tecnología y Medio Ambiente', NULL),
(5, 'MINCI', 'Ministerio de Comercio Interior', NULL),
(6, 'MIC', 'Ministerio de Informatica y Comunicaciones', NULL),
(7, 'MICON', 'Ministerio de la Contruccion', NULL),
(8, 'MINCULT', 'Ministerio de Cultura', NULL),
(9, 'MEP', 'Ministerio de Economia y Planificacion', NULL),
(10, 'MINED', 'Ministerio de Educacion', NULL),
(11, 'MES', 'Ministerio de Educacion Superior', NULL),
(12, 'MFP', 'Ministerio de Finanzas y Precios', NULL),
(13, 'MINFAR', 'Ministerio de las Fuerzas Armadas Revolucionarias', NULL),
(14, 'MINAL', 'Ministerio de la Industria Alimentaria', NULL),
(15, 'MININT', 'Ministerio del Interior', NULL),
(16, 'MINJUS', 'Ministerio de Justicia', NULL),
(17, 'MINREX', 'Ministerio de Relaciones Exteriores', NULL),
(18, 'MTSS', 'Ministerio del Trabajo y Seguridad Social', NULL),
(19, 'MINSAP', 'Ministerio de Salud Publica', NULL),
(20, 'MITRANS', 'Ministerio del Transporte', NULL),
(21, 'MINTUR', 'Ministerio del Turismo', NULL),
(22, 'MINCEX', 'Ministerio del Comercio Exterior y la Inversion Extranjera', NULL),
(23, 'BCC', 'Banco Central de Cuba', NULL),
(24, 'ICRT', 'Instituto Cubano de Radio y Television', NULL),
(25, 'INRH', 'Instituto Nacional de Recursos Hidraulicos', NULL),
(26, 'INDER', 'Instituto Nacional de Deportes, Educacion Fisica y Recreacion', NULL),
(27, 'DATYS', 'Datys Minint', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipio`
--

CREATE TABLE `municipio` (
  `id` int(11) NOT NULL,
  `provincia_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `municipio`
--

INSERT INTO `municipio` (`id`, `provincia_id`, `nombre`, `deleted_at`) VALUES
(1, 4, 'Centro Habana', NULL),
(2, 4, 'Habana Vieja', NULL),
(3, 4, 'Habana del Este', NULL),
(4, 4, 'Alamar', NULL),
(5, 4, 'Guanabacoa', NULL),
(6, 4, 'San Miguel del Padron', NULL),
(7, 4, 'Cotorro', NULL),
(8, 4, 'Boyeros', NULL),
(9, 4, 'Playa', NULL),
(10, 4, 'Plaza de la Revolucion', NULL),
(11, 4, '10 de Octubre', NULL),
(12, 4, 'Lisa', NULL),
(13, 4, 'Regla', NULL),
(14, 4, 'Cerro', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nom_gee`
--

CREATE TABLE `nom_gee` (
  `id` int(11) NOT NULL,
  `corriente_salida_um_id` int(11) DEFAULT NULL,
  `potencia_salida_um_id` int(11) DEFAULT NULL,
  `largo_um_id` int(11) DEFAULT NULL,
  `ancho_um_id` int(11) DEFAULT NULL,
  `alto_um_id` int(11) DEFAULT NULL,
  `peso_um_id` int(11) DEFAULT NULL,
  `marca_id` int(11) DEFAULT NULL,
  `motor_id` int(11) DEFAULT NULL,
  `generador_id` int(11) DEFAULT NULL,
  `voltaje_salida_id` int(11) DEFAULT NULL,
  `modelo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `corrienteSalida` double NOT NULL,
  `potenciaSalida` double NOT NULL,
  `largo` double NOT NULL,
  `ancho` double NOT NULL,
  `alto` double NOT NULL,
  `peso` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `nom_gee`
--

INSERT INTO `nom_gee` (`id`, `corriente_salida_um_id`, `potencia_salida_um_id`, `largo_um_id`, `ancho_um_id`, `alto_um_id`, `peso_um_id`, `marca_id`, `motor_id`, `generador_id`, `voltaje_salida_id`, `modelo`, `deleted_at`, `corrienteSalida`, `potenciaSalida`, `largo`, `ancho`, `alto`, `peso`) VALUES
(1, 2, 3, 4, 4, 4, 5, 10, 5, 6, 7, 'Modelo1', NULL, 0, 0, 0, 0, 0, 0),
(2, 2, 3, 4, 4, 4, 5, 2, 8, 2, 9, 'Modelo2', NULL, 0, 0, 0, 0, 0, 0),
(3, 2, 3, 4, 4, 4, 5, 20, 2, 7, 4, 'Modelo3', NULL, 0, 0, 0, 0, 0, 0),
(4, 2, 3, 4, 4, 4, 5, 13, 7, 6, 8, 'Modelo4', NULL, 0, 0, 0, 0, 0, 0),
(5, 2, 3, 4, 4, 4, 5, 12, 8, 10, 3, 'Modelo5', NULL, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nom_generador`
--

CREATE TABLE `nom_generador` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `modelo` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `nom_generador`
--

INSERT INTO `nom_generador` (`id`, `nombre`, `deleted_at`, `modelo`) VALUES
(1, 'DENYO', NULL, 'DB-0667I'),
(2, 'DENYO', NULL, 'DB-0501I'),
(3, 'DENYO', NULL, 'DB-0661H'),
(4, 'WEG', NULL, 'GTA-200'),
(5, 'HEIMER', NULL, 'ATED40/30'),
(6, 'HEIMER', NULL, 'ATED40/38'),
(7, 'HEIMER', NULL, 'ATED45/42'),
(8, 'WEG', NULL, 'GTA-315'),
(9, 'DENYO', NULL, 'DF-0277I'),
(10, 'DENYO', NULL, 'DF-0220K');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nom_marca`
--

CREATE TABLE `nom_marca` (
  `id` int(11) NOT NULL,
  `marca` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `procedencia` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `nom_marca`
--

INSERT INTO `nom_marca` (`id`, `marca`, `procedencia`, `deleted_at`) VALUES
(1, 'DAEWOO', 'Desconocido', NULL),
(2, 'MAGNA PLUS', 'Desconocido', NULL),
(3, 'DENYO', 'Desconocido', NULL),
(4, 'VOLVO', 'Desconocido', NULL),
(5, 'DETROIT', 'Desconocido', NULL),
(6, 'DEUTZ', 'Desconocido', NULL),
(7, 'YANZ', 'Desconocido', NULL),
(8, 'PEGASSO', 'Desconocido', NULL),
(9, 'MINGZ', 'Desconocido', NULL),
(10, 'SAVOIA', 'Desconocido', NULL),
(11, 'YANMAR', 'Desconocido', NULL),
(12, 'DORMAN', 'Desconocido', NULL),
(13, 'SIMSON-MARELLI', 'Desconocido', NULL),
(14, 'ELCOS', 'Desconocido', NULL),
(15, 'ELECTRA MOLINS', 'Desconocido', NULL),
(16, 'WILSON', 'Desconocido', NULL),
(17, 'GENERAL POWER', 'Desconocido', NULL),
(18, 'ISSOTTA FRANCHINI', 'Desconocido', NULL),
(19, 'SCANIA', 'Desconocido', NULL),
(20, 'MITSUBISCHI', 'Desconocido', NULL),
(21, 'JHON RELY', 'Desconocido', NULL),
(22, 'GENERAL ELECTRIC', 'Desconocido', NULL),
(23, 'ISUZU', 'Desconocido', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nom_moneda`
--

CREATE TABLE `nom_moneda` (
  `id` int(11) NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `nom_moneda`
--

INSERT INTO `nom_moneda` (`id`, `deleted_at`, `nombre`) VALUES
(1, NULL, 'CUP'),
(2, NULL, 'CUC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nom_motor`
--

CREATE TABLE `nom_motor` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `modelo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rpm` int(11) NOT NULL,
  `voltaje` int(11) NOT NULL,
  `cant_baterias` int(11) NOT NULL,
  `aceite` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `nom_motor`
--

INSERT INTO `nom_motor` (`id`, `nombre`, `deleted_at`, `modelo`, `rpm`, `voltaje`, `cant_baterias`, `aceite`) VALUES
(1, 'MB', NULL, 'OM364A', 0, 0, 0, ''),
(2, 'MB', NULL, 'OM-447A', 0, 0, 0, ''),
(3, 'MB', NULL, 'OM-447LA', 0, 0, 0, ''),
(4, 'VOLVO', NULL, 'TAD1642GE', 0, 0, 0, ''),
(5, 'SCANIA', NULL, 'DC1241A', 0, 0, 0, ''),
(6, 'SCANIA', NULL, 'DC1643A', 0, 0, 0, ''),
(7, 'KUBOTA', NULL, 'D1403', 0, 0, 0, ''),
(8, 'HINO', NULL, 'W04D-TG', 0, 0, 0, ''),
(9, 'ISUZO', NULL, 'AA-4LE2', 0, 0, 0, ''),
(10, 'MB', NULL, 'OM366-LA', 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nom_unidad_medida`
--

CREATE TABLE `nom_unidad_medida` (
  `id` int(11) NOT NULL,
  `notacion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `nom_unidad_medida`
--

INSERT INTO `nom_unidad_medida` (`id`, `notacion`, `descripcion`, `deleted_at`) VALUES
(1, 'V', 'Tension/Volt', NULL),
(2, 'A', 'Corriente/Amperes', NULL),
(3, 'W', 'Potencia/Watt', NULL),
(4, 'm', 'Metros', NULL),
(5, 'Kg', 'Kilogramos', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nom_voltaje`
--

CREATE TABLE `nom_voltaje` (
  `id` int(11) NOT NULL,
  `unidad_medida_id` int(11) DEFAULT NULL,
  `voltaje` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `corriente` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `nom_voltaje`
--

INSERT INTO `nom_voltaje` (`id`, `unidad_medida_id`, `voltaje`, `corriente`, `deleted_at`) VALUES
(1, 1, '480 / 277', 'Alterna', NULL),
(2, 1, '480 / 227', 'Alterna', NULL),
(3, 1, '440 / 277', 'Alterna', NULL),
(4, 1, '440 / 227', 'Alterna', NULL),
(5, 1, '240 / 120', 'Alterna', NULL),
(6, 1, '220 / 127', 'Alterna', NULL),
(7, 1, '220 / 110', 'Alterna', NULL),
(8, 1, '400 / 231', 'Alterna', NULL),
(9, 1, '480 / 231', 'Alterna', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincia`
--

CREATE TABLE `provincia` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `provincia`
--

INSERT INTO `provincia` (`id`, `nombre`, `deleted_at`) VALUES
(1, 'Pinar del Rio', '2017-01-11 20:15:59'),
(2, 'Artemisa', '2017-01-11 20:15:59'),
(3, 'Mayabeque', '2017-01-11 20:16:00'),
(4, 'La Habana', NULL),
(5, 'Matanzas', '2017-01-11 20:16:00'),
(6, 'Villa Clara', '2017-01-11 20:16:00'),
(7, 'Cienfuegos', '2017-01-11 20:16:00'),
(8, 'Sancti Spiritus', '2017-01-11 20:16:00'),
(9, 'Ciego de Avila', '2017-01-11 20:16:00'),
(10, 'Camaguey', '2017-01-11 20:16:00'),
(11, 'Las Tunas', '2017-01-11 20:16:00'),
(12, 'Holguin', '2017-01-11 20:16:00'),
(13, 'Granma', '2017-01-11 20:16:00'),
(14, 'Santiago de Cuba', '2017-01-11 20:16:00'),
(15, 'Guantanamo', '2017-01-11 20:16:00'),
(16, 'Isla de la Juventud', '2017-01-11 20:16:00'),
(18, 'ghghgh2', '2017-01-11 18:25:29'),
(19, '23444', '2017-02-16 12:32:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_operacion`
--

CREATE TABLE `registro_operacion` (
  `id` int(11) NOT NULL,
  `gee_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `dia` date NOT NULL,
  `horaInicial` time DEFAULT NULL,
  `horaFinal` time DEFAULT NULL,
  `horametroInicial` double DEFAULT NULL,
  `horametroFinal` double DEFAULT NULL,
  `tiempoTrabajado` double DEFAULT NULL,
  `demandaLiberada` double DEFAULT NULL,
  `energiaGenerada` double DEFAULT NULL,
  `combustibleConsumido` double DEFAULT NULL,
  `combustibleExistencia` double DEFAULT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quienReporta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado_operacion_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `registro_operacion`
--

INSERT INTO `registro_operacion` (`id`, `gee_id`, `tipo_id`, `deleted_at`, `dia`, `horaInicial`, `horaFinal`, `horametroInicial`, `horametroFinal`, `tiempoTrabajado`, `demandaLiberada`, `energiaGenerada`, `combustibleConsumido`, `combustibleExistencia`, `observaciones`, `quienReporta`, `estado_operacion_id`) VALUES
(2, 7, 4, NULL, '2017-02-16', '03:00:00', '03:56:00', 1000, 2000, 1000, 15, 20, 10, 0, NULL, NULL, 1),
(3, 6, 1, NULL, '2017-02-17', '06:07:00', '07:50:00', 100, 115, 15, 100, 150, 2.3, 0, NULL, NULL, 1),
(4, 6, 2, NULL, '2017-02-17', '03:05:00', '04:10:00', 100, 200, 0, 100, 150, 3.2, 0, NULL, 'Energetico', 2),
(5, 6, 4, '2017-02-18 10:40:44', '2017-02-17', '02:02:00', '02:10:00', 1000, 1050, 0, 100, 100, 30, 0, NULL, NULL, 1),
(6, 1, 1, NULL, '2017-02-10', '07:00:00', '07:30:00', 1, 1.5, 0.5, 10, 12, 4, 376.4096, NULL, NULL, 2),
(7, 4, 4, NULL, '2017-02-02', '01:05:00', '03:05:00', 1230, 1233, 3, NULL, NULL, 26.7, 151.617, NULL, NULL, 2),
(8, 5, 6, NULL, '2016-01-03', '06:10:00', '07:00:00', 4560, 4562, 2, 11.3, 2.31, NULL, NULL, NULL, NULL, 2),
(9, 7, 8, NULL, '2016-11-13', '15:03:00', '19:00:00', 6541, 6548, 7, 55.2, 11.3, NULL, NULL, NULL, NULL, 2),
(10, 9, 6, NULL, '2016-07-06', '10:01:00', '12:01:00', 845, 850, 5, 1235.2, 36.2, NULL, NULL, NULL, 'Miguel L.', 1),
(11, 7, 7, NULL, '2015-08-07', '12:04:00', '14:05:00', 266, 669, 403, 123, 52, 3627, 11289765, NULL, NULL, 2),
(12, 7, 3, NULL, '2017-01-05', '02:02:00', '02:48:00', 1523, 1525, 2, 263.2, 55.3, 18, 11293392, NULL, NULL, 2),
(13, 13, 2, NULL, '2016-07-08', '05:05:00', '11:05:00', 1230, 1236, 6, 12.3, 2.36, NULL, NULL, NULL, 'Emily', 1),
(14, 10, 7, NULL, '2016-11-25', '15:10:00', '19:05:00', 569, 576, 7, 33, 20.2, NULL, NULL, 'Pendiente por supervisor', 'Juan G.', 1),
(15, 16, 7, NULL, '2016-07-30', '17:03:00', '04:04:00', 563, 579, 16, 6, 5.2, NULL, NULL, 'Pendiente por Despacho', 'Elvin', 1),
(16, 17, 2, NULL, '2017-02-17', '23:00:00', '03:15:00', 23, 25, 2, 33, 20, NULL, NULL, NULL, 'Jorge Luis c.', 1),
(17, 20, 3, NULL, '2013-02-04', '04:13:00', '09:14:00', 50, 60, 10, 100, 120, 83, 214.2, NULL, NULL, 2),
(18, 1, 1, NULL, '2017-01-07', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 3),
(19, 7, 3, '2017-05-18 01:42:38', '2017-05-18', '05:01:00', '13:02:00', 669, 7000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 7, 6, NULL, '2017-05-18', '05:02:00', '05:04:00', 6548, 7000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resumen_certificacion`
--

CREATE TABLE `resumen_certificacion` (
  `id` int(11) NOT NULL,
  `gee_id` int(11) DEFAULT NULL,
  `municipio_id` int(11) DEFAULT NULL,
  `centro_id` int(11) DEFAULT NULL,
  `marca_id` int(11) DEFAULT NULL,
  `mes` int(11) NOT NULL,
  `anno` int(11) NOT NULL,
  `operacSinCarga` int(11) DEFAULT NULL,
  `operacCarga` int(11) DEFAULT NULL,
  `horasSinCarga` double DEFAULT NULL,
  `horasCarga` double DEFAULT NULL,
  `energiaGenerada` double DEFAULT NULL,
  `combustSinCarga` double DEFAULT NULL,
  `combustCarga` double DEFAULT NULL,
  `combustTotal` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solic_comb_llenado_inicial`
--

CREATE TABLE `solic_comb_llenado_inicial` (
  `id` int(11) NOT NULL,
  `aprobado_id` int(11) DEFAULT NULL,
  `distribucion_id` int(11) DEFAULT NULL,
  `fechaSolicitud` date NOT NULL,
  `fechaAprobacion` date DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noCartaAprobacion` int(11) DEFAULT NULL,
  `cantidad` double NOT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noOrdenDistribucion` int(11) DEFAULT NULL,
  `destino_final_id` int(11) DEFAULT NULL,
  `gee_id` int(11) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `solic_comb_llenado_inicial`
--

INSERT INTO `solic_comb_llenado_inicial` (`id`, `aprobado_id`, `distribucion_id`, `fechaSolicitud`, `fechaAprobacion`, `descripcion`, `noCartaAprobacion`, `cantidad`, `observaciones`, `noOrdenDistribucion`, `destino_final_id`, `gee_id`, `deleted_at`) VALUES
(22, 1, 2, '2017-02-01', '2017-02-02', NULL, NULL, 0.34, NULL, NULL, 17, 17, NULL),
(23, 1, 2, '2017-02-02', '2017-02-03', NULL, NULL, 0.32, NULL, NULL, 9, 9, NULL),
(24, 3, 1, '2017-02-02', '2017-02-05', NULL, NULL, 0.15, NULL, NULL, 4, 4, NULL),
(25, 3, 2, '2017-02-04', '2017-02-05', NULL, NULL, 0.36, NULL, NULL, 5, 5, NULL),
(26, 3, 1, '2017-02-03', '2017-02-04', NULL, NULL, 0.32, NULL, NULL, 1, 1, NULL),
(27, 3, 2, '2017-02-04', '2017-02-05', NULL, NULL, 0.36, NULL, NULL, 6, 6, NULL),
(28, 3, 2, '2017-01-01', '2017-02-08', NULL, 1, 9500, NULL, 15, 7, 7, NULL),
(29, 3, 1, '2016-12-21', '2017-02-04', NULL, 6, 1200.5, NULL, 20, 8, 8, NULL),
(32, 3, 1, '2015-02-03', '2015-02-12', NULL, 25, 0.3, NULL, 18, 10, 10, NULL),
(33, 3, 2, '2014-10-07', '2014-11-02', NULL, NULL, 1.2, NULL, NULL, 11, 11, NULL),
(34, 3, 1, '2017-01-05', '2017-02-03', NULL, NULL, 0.63, NULL, NULL, 12, 12, NULL),
(36, 3, 1, '2014-04-22', '2014-06-04', NULL, NULL, 0.534, NULL, NULL, 13, 13, NULL),
(37, 3, 1, '2015-06-24', '2016-09-08', NULL, NULL, 3.51, NULL, NULL, 14, 14, NULL),
(38, 3, 2, '2016-02-07', '2016-03-08', NULL, NULL, 5.1, NULL, NULL, 15, 15, NULL),
(39, 3, 2, '2016-08-15', '2016-09-06', NULL, NULL, 3.7, NULL, NULL, 16, 16, NULL),
(41, 3, 1, '2017-02-06', '2017-02-11', NULL, NULL, 2.1, NULL, NULL, 4, 19, NULL),
(42, 3, 2, '2017-02-07', '2012-02-10', NULL, NULL, 0.25, NULL, NULL, 14, 20, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_distribucion`
--

CREATE TABLE `tipo_distribucion` (
  `id` int(11) NOT NULL,
  `sigla` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `tipo_distribucion`
--

INSERT INTO `tipo_distribucion` (`id`, `sigla`, `nombre`) VALUES
(1, 'TD', 'Tiro Directo'),
(2, 'TM', 'Tarjeta Magnética');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_operacion`
--

CREATE TABLE `tipo_operacion` (
  `id` int(11) NOT NULL,
  `sigla` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `tipo_operacion`
--

INSERT INTO `tipo_operacion` (`id`, `sigla`, `nombre`) VALUES
(1, 'IA', 'Operación por Interrupción o Avería en el servicio eléctrico'),
(2, 'LD', 'Operación de Liberación de Demanda por Orden de la DGE UNE'),
(3, 'SS', 'Operación de Sincronización al SEN por Orden del DNC'),
(4, 'PS', 'Operación sin carga para dar mantenimiento a las baterías y comprobar la disponibilidad del GEE'),
(5, 'IU', 'Operación ocurrida por trabajos de rehabilitación de líneas, vías libres u alguno otra operación en las líneas que provoque el trabajo de los GEE'),
(6, 'PC', 'Operación realizada con carga para comprobar los parámetros del GEE y la disponibilidad del GEE ante la falta de servicio eléctrico'),
(7, 'LC', 'Prueba del Litros con Carga'),
(8, 'LS', 'Prueba del Litros sin Carga');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `traza`
--

CREATE TABLE `traza` (
  `id` int(11) NOT NULL,
  `usuario` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tabla` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `registro` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `accion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `traza`
--

INSERT INTO `traza` (`id`, `usuario`, `tabla`, `registro`, `ip`, `fecha`, `hora`, `accion`) VALUES
(1, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '00:23:52', 'Loguearse'),
(2, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '00:47:06', 'Loguearse'),
(3, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '00:56:35', 'Loguearse'),
(4, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '00:58:25', 'Loguearse'),
(5, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '01:02:58', 'Loguearse'),
(6, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '01:05:31', 'Loguearse'),
(7, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '15:44:56', 'Loguearse'),
(8, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '16:10:36', 'Loguearse'),
(9, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '16:30:38', 'Loguearse'),
(10, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '18:01:14', 'Loguearse'),
(11, 'admin', 'SigigeeBundle\\Provincia', 'ghghgh', '127.0.0.1', '2017-01-11', '18:06:48', 'Adicionado un(a) " . SigigeeBundle\\Provincia'),
(12, 'admin', 'SigigeeBundle\\Provincia', 'ghghgh2', '127.0.0.1', '2017-01-11', '18:23:54', 'Actualización'),
(13, 'admin', 'SigigeeBundle\\Provincia', 'ghghgh2', '127.0.0.1', '2017-01-11', '18:25:29', 'Eliminación'),
(14, 'admin', 'Application\\Sonata\\UserBundle\\User', 'pepe', '127.0.0.1', '2017-01-11', '19:09:14', 'Adición'),
(15, 'admin', 'SigigeeBundle\\Provincia', 'Pinar del Rio', '127.0.0.1', '2017-01-11', '20:15:59', 'Eliminación'),
(16, 'admin', 'SigigeeBundle\\Provincia', 'Artemisa', '127.0.0.1', '2017-01-11', '20:15:59', 'Eliminación'),
(17, 'admin', 'SigigeeBundle\\Provincia', 'Mayabeque', '127.0.0.1', '2017-01-11', '20:15:59', 'Eliminación'),
(18, 'admin', 'SigigeeBundle\\Provincia', 'Pinar del Rio', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(19, 'admin', 'SigigeeBundle\\Provincia', 'Artemisa', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(20, 'admin', 'SigigeeBundle\\Provincia', 'Matanzas', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(21, 'admin', 'SigigeeBundle\\Provincia', 'Villa Clara', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(22, 'admin', 'SigigeeBundle\\Provincia', 'Mayabeque', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(23, 'admin', 'SigigeeBundle\\Provincia', 'Matanzas', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(24, 'admin', 'SigigeeBundle\\Provincia', 'Cienfuegos', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(25, 'admin', 'SigigeeBundle\\Provincia', 'Sancti Spiritus', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(26, 'admin', 'SigigeeBundle\\Provincia', 'Villa Clara', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(27, 'admin', 'SigigeeBundle\\Provincia', 'Cienfuegos', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(28, 'admin', 'SigigeeBundle\\Provincia', 'Ciego de Avila', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(29, 'admin', 'SigigeeBundle\\Provincia', 'Camaguey', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(30, 'admin', 'SigigeeBundle\\Provincia', 'Sancti Spiritus', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(31, 'admin', 'SigigeeBundle\\Provincia', 'Ciego de Avila', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(32, 'admin', 'SigigeeBundle\\Provincia', 'Las Tunas', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(33, 'admin', 'SigigeeBundle\\Provincia', 'Holguin', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(34, 'admin', 'SigigeeBundle\\Provincia', 'Camaguey', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(35, 'admin', 'SigigeeBundle\\Provincia', 'Las Tunas', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(36, 'admin', 'SigigeeBundle\\Provincia', 'Granma', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(37, 'admin', 'SigigeeBundle\\Provincia', 'Santiago de Cuba', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(38, 'admin', 'SigigeeBundle\\Provincia', 'Holguin', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(39, 'admin', 'SigigeeBundle\\Provincia', 'Granma', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(40, 'admin', 'SigigeeBundle\\Provincia', 'Guantanamo', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(41, 'admin', 'SigigeeBundle\\Provincia', 'Isla de la Juventud', '127.0.0.1', '2017-01-11', '20:16:00', 'Eliminación'),
(42, 'admin', 'SigigeeBundle\\Provincia', 'Santiago de Cuba', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(43, 'admin', 'SigigeeBundle\\Provincia', 'Guantanamo', '127.0.0.1', '2017-01-11', '20:16:00', 'Actualización'),
(44, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-11', '23:41:55', 'Loguearse'),
(45, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-11', '23:41:55', 'Actualización'),
(46, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-13', '19:19:54', 'Loguearse'),
(47, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-13', '19:19:55', 'Actualización'),
(48, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-13', '19:21:04', 'Loguearse'),
(49, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-13', '19:21:04', 'Actualización'),
(50, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-13', '22:32:22', 'Loguearse'),
(51, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-13', '22:32:23', 'Actualización'),
(52, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-13', '22:33:14', 'DesLoguearse'),
(53, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-13', '22:34:26', 'Loguearse'),
(54, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-13', '22:34:26', 'Actualización'),
(55, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-13', '22:34:46', 'DesLoguearse'),
(56, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-13', '22:37:34', 'DesLoguearse'),
(57, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-13', '22:38:57', 'LogIn'),
(58, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-13', '22:38:57', 'Actualización'),
(59, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-13', '22:39:24', 'LogOut'),
(60, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-13', '22:45:37', 'LogIn'),
(61, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-13', '22:45:37', 'Actualización'),
(62, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-13', '22:46:04', 'LogOut'),
(63, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-13', '22:46:23', 'LogIn'),
(64, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-13', '22:46:24', 'Actualización'),
(65, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-14', '00:18:07', 'LogOut'),
(66, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-14', '00:18:30', 'LogIn'),
(67, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-14', '00:18:30', 'Actualización'),
(68, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-14', '00:19:31', 'LogOut'),
(69, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-14', '00:19:53', 'LogIn'),
(70, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-14', '00:19:54', 'Actualización'),
(71, 'admin', 'SigigeeBundle\\EstadoGee', 'OK', '127.0.0.1', '2017-01-15', '12:50:53', 'Adición'),
(72, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH2176', '127.0.0.1', '2017-01-15', '12:51:43', 'Actualización'),
(73, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-15', '17:42:59', 'LogOut'),
(74, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-15', '17:43:28', 'LogIn'),
(75, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-15', '17:43:28', 'Actualización'),
(76, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '512 CARDIOCENTRO WILLIAM SOLER', '127.0.0.1', '2017-01-16', '11:09:30', 'Adición'),
(77, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '512 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-01-16', '11:14:48', 'Adición'),
(78, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '500 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-01-16', '11:48:32', 'Adición'),
(79, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '500 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-01-16', '11:52:42', 'Adición'),
(80, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '500 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-01-16', '11:54:25', 'Actualización'),
(81, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '500 CARDIOCENTRO WILLIAM SOLER', '127.0.0.1', '2017-01-16', '11:58:53', 'Adición'),
(82, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '500 CARDIOCENTRO WILLIAM SOLER', '127.0.0.1', '2017-01-16', '15:47:14', 'Actualización'),
(83, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '3.54 CARDIOCENTRO WILLIAM SOLER', '127.0.0.1', '2017-01-16', '15:50:25', 'Actualización'),
(84, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.21 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-01-16', '15:52:44', 'Actualización'),
(85, 'admin', 'Sistema', 'Login exitoso', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '18:41:59', 'LogIn'),
(86, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '18:41:59', 'Actualización'),
(87, 'admin', 'SigigeeBundle\\Entidad', 'CUBANACAN', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '19:41:48', 'Actualización'),
(88, 'admin', 'SigigeeBundle\\Entidad', 'AEROPUERTO JOSE MARTI TERMINAL 1', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '19:43:08', 'Eliminación'),
(89, 'admin', 'SigigeeBundle\\Ministerio', 'DATYS  Datys Minint', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '19:48:37', 'Adición'),
(90, 'admin', 'SigigeeBundle\\Provincia', '23444', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '19:49:34', 'Adición'),
(91, 'admin', 'SigigeeBundle\\Municipio', 'h423mm', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '19:50:09', 'Adición'),
(92, 'admin', 'SigigeeBundle\\Entidad', 'Casa de abuelos La Milagrosa', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '19:50:25', 'Adición'),
(93, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '56.32 CUBANACAN', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '20:01:30', 'Adición'),
(94, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '56.32 CUBANACAN', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '20:02:05', 'Actualización'),
(95, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '3.54 CARDIOCENTRO WILLIAM SOLER', 'fe80::18e6:22b8:6968:acc4', '2017-01-16', '20:13:52', 'Eliminación'),
(96, 'admin', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-01-18', '15:16:35', 'LogIn'),
(97, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '192.168.137.1', '2017-01-18', '15:16:36', 'Actualización'),
(98, 'admin', 'Sistema', 'LogOut exitoso', '192.168.137.1', '2017-01-18', '17:09:35', 'LogOut'),
(99, 'admin', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-01-18', '17:09:43', 'LogIn'),
(100, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '192.168.137.1', '2017-01-18', '17:09:43', 'Actualización'),
(101, 'admin', 'Sistema', 'LogOut exitoso', '192.168.137.1', '2017-01-18', '17:12:14', 'LogOut'),
(102, 'admin', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-01-18', '17:13:27', 'LogIn'),
(103, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '192.168.137.1', '2017-01-18', '17:13:27', 'Actualización'),
(104, 'admin', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-01-20', '13:19:33', 'LogIn'),
(105, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '192.168.137.1', '2017-01-20', '13:19:34', 'Actualización'),
(106, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-24', '18:28:22', 'LogOut'),
(107, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-24', '18:29:05', 'LogIn'),
(108, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-24', '18:29:05', 'Actualización'),
(109, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-30', '16:05:02', 'LogOut'),
(110, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-30', '16:14:47', 'LogIn'),
(111, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-30', '16:14:47', 'Actualización'),
(112, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-30', '16:15:31', 'LogOut'),
(113, 'admin', 'Sistema', 'Login exitoso', '::1', '2017-01-31', '11:28:38', 'LogIn'),
(114, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '::1', '2017-01-31', '11:28:39', 'Actualización'),
(115, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-31', '12:43:21', 'LogIn'),
(116, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-31', '12:43:21', 'Actualización'),
(117, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-01-31', '12:52:00', 'LogOut'),
(118, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-01-31', '12:52:09', 'LogIn'),
(119, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-01-31', '12:52:09', 'Actualización'),
(120, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-11', '10:22:56', 'LogIn'),
(121, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-02-11', '10:22:57', 'Actualización'),
(122, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH1899', '127.0.0.1', '2017-02-13', '08:30:05', 'Eliminación'),
(123, 'admin', 'SigigeeBundle\\Entidad', 'BANCO METROPOLITANO DIRECCION DE SERVICIOS GENERALES', '127.0.0.1', '2017-02-13', '08:30:05', 'Eliminación'),
(124, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH1899', '127.0.0.1', '2017-02-13', '08:30:05', 'Actualización'),
(125, 'admin', 'SigigeeBundle\\Entidad', 'BANCO METROPOLITANO DIRECCION DE SERVICIOS GENERALES', '127.0.0.1', '2017-02-13', '08:30:05', 'Actualización'),
(126, 'admin', 'SigigeeBundle\\EstadoGee', 'Sin Combustible', '127.0.0.1', '2017-02-15', '19:42:47', 'Adición'),
(127, 'admin', 'SigigeeBundle\\EstadoGee', 'Óptimo', '127.0.0.1', '2017-02-15', '19:44:31', 'Actualización'),
(128, 'admin', 'SigigeeBundle\\EstadoGee', 'Sin Combustible', '127.0.0.1', '2017-02-15', '19:45:07', 'Eliminación'),
(129, 'admin', 'SigigeeBundle\\EstadoGee', 'Baja Cobertura', '127.0.0.1', '2017-02-15', '19:45:56', 'Adición'),
(130, 'admin', 'SigigeeBundle\\EstadoGee', 'Nivel Critico', '127.0.0.1', '2017-02-15', '19:46:25', 'Adición'),
(131, 'admin', 'SigigeeBundle\\EstadoGee', 'Sin Combustible', '127.0.0.1', '2017-02-15', '19:47:01', 'Adición'),
(132, 'admin', 'SigigeeBundle\\Entidad', 'CUBANACAN', '127.0.0.1', '2017-02-15', '20:28:58', 'Actualización'),
(134, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '1 PALMARES RESTAURANTES', '127.0.0.1', '2017-02-16', '12:24:19', 'Adición'),
(135, 'admin', 'SigigeeBundle\\AsignacionComb', 'PALMARES RESTAURANTES 1188.78 Llenado Inicial Pendiente', '127.0.0.1', '2017-02-16', '12:24:21', 'Adición'),
(136, 'admin', 'SigigeeBundle\\Entidad', 'CUBANACAN', '127.0.0.1', '2017-02-16', '12:30:14', 'Actualización'),
(137, 'admin', 'SigigeeBundle\\Provincia', '23444', '127.0.0.1', '2017-02-16', '12:32:08', 'Eliminación'),
(138, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.5 PALMARES RESTAURANTES', '127.0.0.1', '2017-02-16', '12:40:15', 'Actualización'),
(139, 'admin', 'SigigeeBundle\\AsignacionComb', 'PALMARES RESTAURANTES 594.39 Llenado Inicial Pendiente', '127.0.0.1', '2017-02-16', '12:40:16', 'Actualización'),
(140, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.5 PALMARES RESTAURANTES', '127.0.0.1', '2017-02-16', '12:41:51', 'Eliminación'),
(141, 'admin', 'SigigeeBundle\\AsignacionComb', 'PALMARES RESTAURANTES 594.39 Llenado Inicial Pendiente', '127.0.0.1', '2017-02-16', '12:41:52', 'Eliminación'),
(144, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.5 PALMARES RESTAURANTES', '127.0.0.1', '2017-02-16', '12:50:13', 'Eliminación'),
(145, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.5 PALMARES RESTAURANTES', '127.0.0.1', '2017-02-16', '12:52:12', 'Eliminación'),
(146, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '2 SERVAC', '127.0.0.1', '2017-02-16', '12:53:54', 'Adición'),
(148, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-16', '15:59:53', 'Adición'),
(149, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-16', '20:52:34', 'Actualización'),
(150, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-17', '08:27:46', 'LogOut'),
(151, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-17', '08:28:00', 'LogIn'),
(152, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-02-17', '08:28:00', 'Actualización'),
(153, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-17', '08:28:20', 'LogOut'),
(154, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-17', '08:33:53', 'LogIn'),
(155, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-02-17', '08:33:53', 'Actualización'),
(156, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '10:10:47', 'Actualización'),
(157, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '10:12:01', 'Actualización'),
(158, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '10:23:39', 'Actualización'),
(159, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '10:24:40', 'Actualización'),
(160, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '10:53:05', 'Actualización'),
(161, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '10:53:36', 'Actualización'),
(162, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '10:58:37', 'Actualización'),
(163, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '10:59:23', 'Actualización'),
(164, 'admin', 'SigigeeBundle\\CertifOperacion', '2CH3356', '127.0.0.1', '2017-02-17', '10:59:25', 'Adición'),
(165, 'admin', 'SigigeeBundle\\CertifOperacion', '3CH3356', '127.0.0.1', '2017-02-17', '10:59:25', 'Adición'),
(166, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '11:09:06', 'Actualización'),
(167, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '11:11:14', 'Actualización'),
(168, 'admin', 'SigigeeBundle\\CertifOperacion', '4CH3356', '127.0.0.1', '2017-02-17', '11:11:15', 'Adición'),
(169, 'admin', 'SigigeeBundle\\CertifOperacion', '5CH3356', '127.0.0.1', '2017-02-17', '11:11:15', 'Adición'),
(170, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '11:19:34', 'Actualización'),
(171, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '11:20:08', 'Actualización'),
(172, 'admin', 'SigigeeBundle\\CertifOperacion', '6CH3356', '127.0.0.1', '2017-02-17', '11:20:09', 'Adición'),
(173, 'admin', 'SigigeeBundle\\CertifOperacion', '7CH3356', '127.0.0.1', '2017-02-17', '11:20:09', 'Adición'),
(174, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '11:23:17', 'Actualización'),
(175, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '11:25:34', 'Actualización'),
(176, 'admin', 'SigigeeBundle\\CertifOperacion', '8CH3356', '127.0.0.1', '2017-02-17', '11:25:35', 'Adición'),
(177, 'admin', 'SigigeeBundle\\CertifOperacion', '9CH3356', '127.0.0.1', '2017-02-17', '11:25:35', 'Adición'),
(178, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '12:04:06', 'Actualización'),
(179, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '12:04:39', 'Actualización'),
(180, 'admin', 'SigigeeBundle\\CertifOperacion', '10CH3356', '127.0.0.1', '2017-02-17', '12:04:39', 'Adición'),
(181, 'admin', 'SigigeeBundle\\CertifOperacion', '11CH3356', '127.0.0.1', '2017-02-17', '12:04:39', 'Adición'),
(182, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '12:08:47', 'Actualización'),
(183, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '12:09:20', 'Actualización'),
(184, 'admin', 'SigigeeBundle\\CertifOperacion', '12CH3356', '127.0.0.1', '2017-02-17', '12:09:20', 'Adición'),
(185, 'admin', 'SigigeeBundle\\CertifOperacion', '13CH3356', '127.0.0.1', '2017-02-17', '12:09:20', 'Adición'),
(186, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '12:13:27', 'Actualización'),
(187, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '127.0.0.1', '2017-02-17', '12:18:11', 'Actualización'),
(188, 'admin', 'SigigeeBundle\\CertifOperacion', '14CH3356', '127.0.0.1', '2017-02-17', '12:18:12', 'Adición'),
(189, 'admin', 'SigigeeBundle\\CertifOperacion', '15CH3356', '127.0.0.1', '2017-02-17', '12:18:12', 'Adición'),
(190, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '14:00:36', 'Adición'),
(191, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '14:04:38', 'Actualización'),
(192, 'admin', 'SigigeeBundle\\CertifOperacion', '16CH5410', '127.0.0.1', '2017-02-17', '14:04:39', 'Adición'),
(193, 'admin', 'SigigeeBundle\\RegistroOperacion', '4 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '14:08:43', 'Adición'),
(194, 'admin', 'SigigeeBundle\\RegistroOperacion', '4 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '14:10:19', 'Actualización'),
(195, 'admin', 'SigigeeBundle\\CertifOperacion', '17CH5410', '127.0.0.1', '2017-02-17', '14:10:19', 'Adición'),
(196, 'admin', 'Application\\Sonata\\UserBundle\\User', 'regla', '127.0.0.1', '2017-02-17', '14:28:34', 'Adición'),
(197, 'admin', 'Application\\Sonata\\UserBundle\\User', 'regla', '127.0.0.1', '2017-02-17', '14:29:52', 'Actualización'),
(198, 'admin', 'Application\\Sonata\\UserBundle\\User', 'pepe', '127.0.0.1', '2017-02-17', '14:31:48', 'Actualización'),
(199, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-17', '14:33:48', 'LogOut'),
(200, 'pepe', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-17', '14:34:52', 'LogIn'),
(201, 'pepe', 'Application\\Sonata\\UserBundle\\User', 'pepe', '127.0.0.1', '2017-02-17', '14:34:52', 'Actualización'),
(202, 'pepe', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-17', '14:35:41', 'LogOut'),
(203, 'regla', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-17', '14:36:28', 'LogIn'),
(204, 'regla', 'Application\\Sonata\\UserBundle\\User', 'regla', '127.0.0.1', '2017-02-17', '14:36:28', 'Actualización'),
(205, 'regla', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-17', '14:37:04', 'LogOut'),
(206, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-17', '15:48:10', 'LogIn'),
(207, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-02-17', '15:48:12', 'Actualización'),
(208, 'admin', 'SigigeeBundle\\RegistroOperacion', '4 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '16:52:59', 'Actualización'),
(209, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '16:53:00', 'Adición'),
(210, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '16:56:54', 'Actualización'),
(211, 'admin', 'SigigeeBundle\\CertifOperacion', '19CH5410', '127.0.0.1', '2017-02-17', '16:56:54', 'Adición'),
(212, 'admin', 'SigigeeBundle\\CertifOperacion', '19CH5410', '127.0.0.1', '2017-02-17', '16:58:56', 'Eliminación'),
(213, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '17:00:03', 'Actualización'),
(214, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '17:01:31', 'Actualización'),
(215, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '17:01:59', 'Actualización'),
(216, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '17:02:00', 'Actualización'),
(217, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '18:34:02', 'Actualización'),
(218, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '18:36:17', 'Actualización'),
(219, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '18:36:54', 'Actualización'),
(220, 'admin', 'SigigeeBundle\\RegistroOperacion', '5 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:40:11', 'Adición'),
(221, 'admin', 'SigigeeBundle\\RegistroOperacion', '5 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:40:41', 'Actualización'),
(222, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '18:40:42', 'Actualización'),
(223, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '18:40:42', 'Actualización'),
(224, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:46:13', 'Actualización'),
(225, 'admin', 'SigigeeBundle\\RegistroOperacion', '4 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:46:20', 'Actualización'),
(226, 'admin', 'SigigeeBundle\\RegistroOperacion', '5 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:46:29', 'Actualización'),
(227, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:48:01', 'Actualización'),
(228, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '18:48:01', 'Actualización'),
(229, 'admin', 'SigigeeBundle\\RegistroOperacion', '4 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:48:31', 'Actualización'),
(230, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '18:48:31', 'Actualización'),
(231, 'admin', 'SigigeeBundle\\RegistroOperacion', '5 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:48:59', 'Actualización'),
(232, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '18:49:00', 'Actualización'),
(233, 'admin', 'SigigeeBundle\\CertifOperacion', '18CH5410', '127.0.0.1', '2017-02-17', '18:52:25', 'Eliminación'),
(234, 'admin', 'SigigeeBundle\\RegistroOperacion', '4 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:52:48', 'Actualización'),
(235, 'admin', 'SigigeeBundle\\RegistroOperacion', '5 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:52:56', 'Actualización'),
(236, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:53:04', 'Actualización'),
(237, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:55:43', 'Actualización'),
(238, 'admin', 'SigigeeBundle\\CertifOperacion', '20CH5410', '127.0.0.1', '2017-02-17', '18:55:44', 'Adición'),
(239, 'admin', 'SigigeeBundle\\RegistroOperacion', '4 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:56:37', 'Actualización'),
(240, 'admin', 'SigigeeBundle\\CertifOperacion', '20CH5410', '127.0.0.1', '2017-02-17', '18:56:37', 'Actualización'),
(241, 'admin', 'SigigeeBundle\\RegistroOperacion', '5 CH5410 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-17', '18:57:33', 'Actualización'),
(242, 'admin', 'SigigeeBundle\\CertifOperacion', '20CH5410', '127.0.0.1', '2017-02-17', '18:57:34', 'Actualización'),
(243, 'admin', 'SigigeeBundle\\CertifOperacion', '20CH5410', '127.0.0.1', '2017-02-17', '21:13:33', 'Actualización'),
(244, 'admin', 'SigigeeBundle\\NomMoneda', 'CUP', '127.0.0.1', '2017-02-17', '23:08:39', 'Adición'),
(245, 'admin', 'SigigeeBundle\\NomMoneda', 'CUC', '127.0.0.1', '2017-02-17', '23:09:04', 'Adición'),
(246, 'admin', 'SigigeeBundle\\Entidad', 'INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-02-17', '23:19:52', 'Actualización'),
(254, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.21 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-02-18', '00:30:51', 'Eliminación'),
(255, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.32 CUBANACAN', '127.0.0.1', '2017-02-18', '00:30:51', 'Eliminación'),
(256, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '2 SERVAC', '127.0.0.1', '2017-02-18', '00:30:51', 'Eliminación'),
(257, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.21 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-02-18', '00:30:51', 'Actualización'),
(258, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.32 CUBANACAN', '127.0.0.1', '2017-02-18', '00:30:51', 'Actualización'),
(259, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.25 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-02-18', '00:35:47', 'Adición'),
(260, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.25 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-02-18', '00:37:44', 'Eliminación'),
(261, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.25 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-02-18', '01:32:03', 'Adición'),
(262, 'admin', 'SigigeeBundle\\AsignacionComb', 'INSTITUTO DE DESARROLLO AUTOMOTOR 297.195 CH7291', '127.0.0.1', '2017-02-18', '01:32:03', 'Adición'),
(263, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.32 DIRECCION PROVINCIAL DE EDUCACION', '127.0.0.1', '2017-02-18', '01:34:14', 'Adición'),
(264, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.34 INSTITUTO DE DESARROLLO AUTOMOTOR', '127.0.0.1', '2017-02-18', '01:36:50', 'Actualización'),
(265, 'admin', 'SigigeeBundle\\AsignacionComb', 'INSTITUTO DE DESARROLLO AUTOMOTOR 404.1852 CH7291', '127.0.0.1', '2017-02-18', '01:36:50', 'Actualización'),
(266, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.32 DIRECCION PROVINCIAL DE EDUCACION', '127.0.0.1', '2017-02-18', '01:39:06', 'Actualización'),
(267, 'admin', 'SigigeeBundle\\AsignacionComb', 'DIRECCION PROVINCIAL DE EDUCACION 380.4096 CH3046', '127.0.0.1', '2017-02-18', '01:39:06', 'Adición'),
(268, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.15 PALMARES RESTAURANTES', '127.0.0.1', '2017-02-18', '02:59:36', 'Adición'),
(269, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6221', '127.0.0.1', '2017-02-18', '02:59:36', 'Actualización'),
(270, 'admin', 'SigigeeBundle\\AsignacionComb', 'PALMARES RESTAURANTES 178.317 CH6221', '127.0.0.1', '2017-02-18', '02:59:36', 'Adición'),
(271, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6221', '127.0.0.1', '2017-02-18', '03:03:24', 'Actualización'),
(272, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6221', '127.0.0.1', '2017-02-18', '03:06:54', 'Actualización'),
(273, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH7556', '127.0.0.1', '2017-02-18', '03:09:06', 'Actualización'),
(274, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.36 CARDIOCENTRO WILLIAM SOLER', '127.0.0.1', '2017-02-18', '03:21:54', 'Adición'),
(275, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH7556', '127.0.0.1', '2017-02-18', '03:21:55', 'Actualización'),
(276, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH7556', '127.0.0.1', '2017-02-18', '03:21:55', 'Actualización'),
(277, 'admin', 'SigigeeBundle\\AsignacionComb', 'CARDIOCENTRO WILLIAM SOLER 427.9608 CH7556', '127.0.0.1', '2017-02-18', '03:21:55', 'Adición'),
(278, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH7556', '127.0.0.1', '2017-02-18', '03:24:55', 'Actualización'),
(279, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH7556', '127.0.0.1', '2017-02-18', '03:30:45', 'Actualización'),
(280, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH7556', '127.0.0.1', '2017-02-18', '03:30:45', 'Actualización'),
(281, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH2176', '127.0.0.1', '2017-02-18', '03:47:12', 'Actualización'),
(282, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH2176', '127.0.0.1', '2017-02-18', '03:47:12', 'Actualización'),
(283, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.32 CUBANACAN', '127.0.0.1', '2017-02-18', '03:48:33', 'Adición'),
(284, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH2176', '127.0.0.1', '2017-02-18', '03:48:33', 'Actualización'),
(285, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH2176', '127.0.0.1', '2017-02-18', '03:48:33', 'Actualización'),
(286, 'admin', 'SigigeeBundle\\AsignacionComb', 'CUBANACAN 380.4096 CH2176', '127.0.0.1', '2017-02-18', '03:48:33', 'Adición'),
(287, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6221', '127.0.0.1', '2017-02-18', '03:50:45', 'Actualización'),
(288, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6221', '127.0.0.1', '2017-02-18', '03:50:46', 'Actualización'),
(289, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH5410', '127.0.0.1', '2017-02-18', '03:54:56', 'Actualización'),
(290, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH5410', '127.0.0.1', '2017-02-18', '03:54:57', 'Actualización'),
(291, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.36 CLINICA CIRA GARCIA', '127.0.0.1', '2017-02-18', '03:56:08', 'Adición'),
(292, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH5410', '127.0.0.1', '2017-02-18', '03:56:08', 'Actualización'),
(293, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH5410', '127.0.0.1', '2017-02-18', '03:56:08', 'Actualización'),
(294, 'admin', 'SigigeeBundle\\AsignacionComb', 'CLINICA CIRA GARCIA 427.9608 CH5410', '127.0.0.1', '2017-02-18', '03:56:08', 'Adición'),
(295, 'admin', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-02-18', '09:25:41', 'LogIn'),
(296, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '192.168.137.1', '2017-02-18', '09:25:41', 'Actualización'),
(297, 'admin', 'Sistema', 'LogOut exitoso', '192.168.137.1', '2017-02-18', '09:26:07', 'LogOut'),
(298, 'admin', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-02-18', '09:27:13', 'LogIn'),
(299, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '192.168.137.1', '2017-02-18', '09:27:13', 'Actualización'),
(300, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '09:33:57', 'Actualización'),
(301, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '09:33:57', 'Actualización'),
(302, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '09:34:20', 'Actualización'),
(303, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '09:34:20', 'Actualización'),
(304, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6217', '192.168.137.1', '2017-02-18', '09:35:02', 'Actualización'),
(305, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6217', '192.168.137.1', '2017-02-18', '09:35:02', 'Actualización'),
(306, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH3046', '192.168.137.1', '2017-02-18', '09:35:46', 'Actualización'),
(307, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH3046', '192.168.137.1', '2017-02-18', '09:35:46', 'Actualización'),
(308, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6390', '192.168.137.1', '2017-02-18', '09:36:25', 'Actualización'),
(309, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6390', '192.168.137.1', '2017-02-18', '09:36:25', 'Actualización'),
(310, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9135', '192.168.137.1', '2017-02-18', '09:37:05', 'Actualización'),
(311, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9135', '192.168.137.1', '2017-02-18', '09:37:05', 'Actualización'),
(312, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6122', '192.168.137.1', '2017-02-18', '09:37:37', 'Actualización'),
(313, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6122', '192.168.137.1', '2017-02-18', '09:37:37', 'Actualización'),
(314, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9624', '192.168.137.1', '2017-02-18', '09:38:09', 'Actualización'),
(315, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9624', '192.168.137.1', '2017-02-18', '09:38:09', 'Actualización'),
(316, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH5082', '192.168.137.1', '2017-02-18', '09:38:49', 'Actualización'),
(317, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH5082', '192.168.137.1', '2017-02-18', '09:38:49', 'Actualización'),
(318, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH4507', '192.168.137.1', '2017-02-18', '09:39:25', 'Actualización'),
(319, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH4507', '192.168.137.1', '2017-02-18', '09:39:25', 'Actualización'),
(320, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH2848', '192.168.137.1', '2017-02-18', '09:40:05', 'Actualización'),
(321, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH2848', '192.168.137.1', '2017-02-18', '09:40:05', 'Actualización'),
(322, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH7291', '192.168.137.1', '2017-02-18', '09:40:42', 'Actualización'),
(323, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH7291', '192.168.137.1', '2017-02-18', '09:40:42', 'Actualización'),
(324, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9020', '192.168.137.1', '2017-02-18', '09:41:14', 'Actualización'),
(325, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9020', '192.168.137.1', '2017-02-18', '09:41:14', 'Actualización'),
(326, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '9500 COPPELIA', '192.168.137.1', '2017-02-18', '09:42:28', 'Adición'),
(327, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '09:42:28', 'Actualización'),
(328, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '09:42:28', 'Actualización'),
(329, 'admin', 'SigigeeBundle\\AsignacionComb', 'COPPELIA 11293410 CH3356', '192.168.137.1', '2017-02-18', '09:42:28', 'Adición'),
(330, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '1200.5 DATYS', '192.168.137.1', '2017-02-18', '09:43:36', 'Adición'),
(331, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6217', '192.168.137.1', '2017-02-18', '09:43:36', 'Actualización'),
(332, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6217', '192.168.137.1', '2017-02-18', '09:43:36', 'Actualización'),
(333, 'admin', 'SigigeeBundle\\AsignacionComb', 'DATYS 1427130.39 CH6217', '192.168.137.1', '2017-02-18', '09:43:36', 'Adición'),
(334, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.3 FRIGORIFICO CARLOS III', '192.168.137.1', '2017-02-18', '09:46:16', 'Adición'),
(335, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6390', '192.168.137.1', '2017-02-18', '09:46:16', 'Actualización'),
(336, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6390', '192.168.137.1', '2017-02-18', '09:46:16', 'Actualización'),
(337, 'admin', 'SigigeeBundle\\AsignacionComb', 'FRIGORIFICO CARLOS III 356.634 CH6390', '192.168.137.1', '2017-02-18', '09:46:16', 'Adición'),
(338, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '1.2 HAVANATUR', '192.168.137.1', '2017-02-18', '09:47:28', 'Adición'),
(339, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9135', '192.168.137.1', '2017-02-18', '09:47:29', 'Actualización'),
(340, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9135', '192.168.137.1', '2017-02-18', '09:47:29', 'Actualización'),
(341, 'admin', 'SigigeeBundle\\AsignacionComb', 'HAVANATUR 1426.536 CH9135', '192.168.137.1', '2017-02-18', '09:47:29', 'Adición'),
(342, 'admin', 'SigigeeBundle\\RegistroOperacion', '6 CH2176 CUBANACAN', '127.0.0.1', '2017-02-18', '09:47:35', 'Adición'),
(343, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.63 INMIGRACION Y EXTRANJERIA', '192.168.137.1', '2017-02-18', '09:48:19', 'Adición'),
(344, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6122', '192.168.137.1', '2017-02-18', '09:48:19', 'Actualización'),
(345, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH6122', '192.168.137.1', '2017-02-18', '09:48:19', 'Actualización'),
(346, 'admin', 'SigigeeBundle\\AsignacionComb', 'INMIGRACION Y EXTRANJERIA 748.9314 CH6122', '192.168.137.1', '2017-02-18', '09:48:19', 'Adición'),
(347, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '2.36 SERVAC', '192.168.137.1', '2017-02-18', '09:49:34', 'Adición'),
(348, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9624', '192.168.137.1', '2017-02-18', '09:49:34', 'Actualización'),
(349, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9624', '192.168.137.1', '2017-02-18', '09:49:34', 'Actualización'),
(350, 'admin', 'SigigeeBundle\\AsignacionComb', 'SERVAC 2805.5208 CH9624', '192.168.137.1', '2017-02-18', '09:49:34', 'Adición'),
(351, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '3.51 UM-9058', '192.168.137.1', '2017-02-18', '09:50:21', 'Adición'),
(352, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH5082', '192.168.137.1', '2017-02-18', '09:50:22', 'Actualización'),
(353, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH5082', '192.168.137.1', '2017-02-18', '09:50:22', 'Actualización'),
(354, 'admin', 'SigigeeBundle\\AsignacionComb', 'UM-9058 4172.6178 CH5082', '192.168.137.1', '2017-02-18', '09:50:22', 'Adición'),
(355, 'admin', 'SigigeeBundle\\RegistroOperacion', '6 CH2176 CUBANACAN', '127.0.0.1', '2017-02-18', '09:50:52', 'Actualización'),
(356, 'admin', 'Proxies\\__CG__\\SigigeeBundle\\ExistenciaGee', 'CH2176', '127.0.0.1', '2017-02-18', '09:50:53', 'Actualización'),
(357, 'admin', 'Proxies\\__CG__\\SigigeeBundle\\ExistenciaGee', 'CH2176', '127.0.0.1', '2017-02-18', '09:50:53', 'Actualización'),
(358, 'admin', 'SigigeeBundle\\CertifOperacion', '21CH2176', '127.0.0.1', '2017-02-18', '09:50:53', 'Adición'),
(359, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '5.1 UNIVERSIDAD DE LA HABANA', '192.168.137.1', '2017-02-18', '09:51:13', 'Adición'),
(360, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH4507', '192.168.137.1', '2017-02-18', '09:51:13', 'Actualización'),
(361, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH4507', '192.168.137.1', '2017-02-18', '09:51:13', 'Actualización'),
(362, 'admin', 'SigigeeBundle\\AsignacionComb', 'UNIVERSIDAD DE LA HABANA 6062.778 CH4507', '192.168.137.1', '2017-02-18', '09:51:13', 'Adición'),
(363, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '3.7 EMPRESA DE CAMIONES NARCISO LOPEZ ROSELLO', '192.168.137.1', '2017-02-18', '09:52:06', 'Adición'),
(364, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH2848', '192.168.137.1', '2017-02-18', '09:52:07', 'Actualización'),
(365, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH2848', '192.168.137.1', '2017-02-18', '09:52:07', 'Actualización'),
(366, 'admin', 'SigigeeBundle\\AsignacionComb', 'EMPRESA DE CAMIONES NARCISO LOPEZ ROSELLO 4398.486 CH2848', '192.168.137.1', '2017-02-18', '09:52:07', 'Adición'),
(367, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '2.1 PALMARES RESTAURANTES', '192.168.137.1', '2017-02-18', '09:53:16', 'Adición'),
(368, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9020', '192.168.137.1', '2017-02-18', '09:53:16', 'Actualización'),
(369, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9020', '192.168.137.1', '2017-02-18', '09:53:16', 'Actualización'),
(370, 'admin', 'SigigeeBundle\\AsignacionComb', 'PALMARES RESTAURANTES 2496.438 CH9020', '192.168.137.1', '2017-02-18', '09:53:16', 'Adición'),
(371, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '192.168.137.1', '2017-02-18', '10:40:44', 'Eliminación'),
(372, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '192.168.137.1', '2017-02-18', '10:40:44', 'Eliminación'),
(373, 'admin', 'SigigeeBundle\\RegistroOperacion', '4 CH5410 CLINICA CIRA GARCIA', '192.168.137.1', '2017-02-18', '10:40:44', 'Eliminación'),
(374, 'admin', 'SigigeeBundle\\RegistroOperacion', '2 CH3356 COPPELIA', '192.168.137.1', '2017-02-18', '10:40:44', 'Actualización'),
(375, 'admin', 'SigigeeBundle\\RegistroOperacion', '3 CH5410 CLINICA CIRA GARCIA', '192.168.137.1', '2017-02-18', '10:40:44', 'Actualización'),
(376, 'admin', 'SigigeeBundle\\RegistroOperacion', '5 CH5410 CLINICA CIRA GARCIA', '192.168.137.1', '2017-02-18', '10:40:44', 'Eliminación'),
(377, 'admin', 'SigigeeBundle\\RegistroOperacion', '4 CH5410 CLINICA CIRA GARCIA', '192.168.137.1', '2017-02-18', '10:40:44', 'Actualización'),
(378, 'admin', 'SigigeeBundle\\RegistroOperacion', '5 CH5410 CLINICA CIRA GARCIA', '192.168.137.1', '2017-02-18', '10:40:44', 'Actualización'),
(379, 'admin', 'SigigeeBundle\\CertifOperacion', '22CH2176', '192.168.137.1', '2017-02-18', '10:43:46', 'Adición'),
(380, 'admin', 'SigigeeBundle\\CertifOperacion', '22CH2176', '192.168.137.1', '2017-02-18', '10:44:43', 'Actualización'),
(381, 'admin', 'SigigeeBundle\\CertifOperacion', '21CH2176', '192.168.137.1', '2017-02-18', '10:45:36', 'Actualización'),
(382, 'admin', 'SigigeeBundle\\CertifOperacion', '23CH3356', '192.168.137.1', '2017-02-18', '10:46:54', 'Adición'),
(383, 'admin', 'SigigeeBundle\\CertifOperacion', '24CH6217', '192.168.137.1', '2017-02-18', '10:48:00', 'Adición'),
(384, 'admin', 'SigigeeBundle\\CertifOperacion', '25CH6390', '192.168.137.1', '2017-02-18', '10:48:55', 'Adición'),
(385, 'admin', 'SigigeeBundle\\RegistroOperacion', '7 CH6221 PALMARES RESTAURANTES', '192.168.137.1', '2017-02-18', '10:52:55', 'Adición'),
(386, 'admin', 'SigigeeBundle\\CertifOperacion', '22CH2176', '127.0.0.1', '2017-02-18', '10:53:04', 'Eliminación'),
(387, 'admin', 'SigigeeBundle\\CertifOperacion', '23CH3356', '127.0.0.1', '2017-02-18', '10:53:04', 'Eliminación'),
(388, 'admin', 'SigigeeBundle\\CertifOperacion', '24CH6217', '127.0.0.1', '2017-02-18', '10:53:04', 'Eliminación'),
(389, 'admin', 'SigigeeBundle\\CertifOperacion', '22CH2176', '127.0.0.1', '2017-02-18', '10:53:04', 'Actualización'),
(390, 'admin', 'SigigeeBundle\\CertifOperacion', '23CH3356', '127.0.0.1', '2017-02-18', '10:53:04', 'Actualización'),
(391, 'admin', 'SigigeeBundle\\CertifOperacion', '25CH6390', '127.0.0.1', '2017-02-18', '10:53:04', 'Eliminación'),
(392, 'admin', 'SigigeeBundle\\CertifOperacion', '24CH6217', '127.0.0.1', '2017-02-18', '10:53:04', 'Actualización'),
(393, 'admin', 'SigigeeBundle\\CertifOperacion', '25CH6390', '127.0.0.1', '2017-02-18', '10:53:04', 'Actualización'),
(394, 'admin', 'SigigeeBundle\\RegistroOperacion', '8 CH7556 CARDIOCENTRO WILLIAM SOLER', '192.168.137.1', '2017-02-18', '10:54:01', 'Adición'),
(395, 'admin', 'SigigeeBundle\\CertifOperacion', '21CH2176', '127.0.0.1', '2017-02-18', '10:54:42', 'Actualización'),
(396, 'admin', 'SigigeeBundle\\RegistroOperacion', '9 CH3356 COPPELIA', '192.168.137.1', '2017-02-18', '10:54:44', 'Adición'),
(397, 'admin', 'SigigeeBundle\\RegistroOperacion', '10 CH3046 DIRECCION PROVINCIAL DE EDUCACION', '192.168.137.1', '2017-02-18', '10:55:52', 'Adición'),
(398, 'admin', 'SigigeeBundle\\RegistroOperacion', '11 CH3356 COPPELIA', '192.168.137.1', '2017-02-18', '10:57:00', 'Adición'),
(399, 'admin', 'SigigeeBundle\\CertifOperacion', '26CH3356', '192.168.137.1', '2017-02-18', '10:58:43', 'Adición'),
(400, 'admin', 'SigigeeBundle\\RegistroOperacion', '11 CH3356 COPPELIA', '192.168.137.1', '2017-02-18', '11:02:10', 'Actualización'),
(401, 'admin', 'SigigeeBundle\\RegistroOperacion', '12 CH3356 COPPELIA', '192.168.137.1', '2017-02-18', '11:03:29', 'Adición'),
(402, 'admin', 'SigigeeBundle\\RegistroOperacion', '12 CH3356 COPPELIA', '192.168.137.1', '2017-02-18', '11:03:55', 'Actualización'),
(403, 'admin', 'Proxies\\__CG__\\SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '11:03:55', 'Actualización'),
(404, 'admin', 'Proxies\\__CG__\\SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '11:03:55', 'Actualización'),
(405, 'admin', 'SigigeeBundle\\CertifOperacion', '27CH3356', '192.168.137.1', '2017-02-18', '11:03:56', 'Adición'),
(406, 'admin', 'SigigeeBundle\\RegistroOperacion', '7 CH6221 PALMARES RESTAURANTES', '192.168.137.1', '2017-02-18', '11:04:39', 'Actualización'),
(407, 'admin', 'Proxies\\__CG__\\SigigeeBundle\\ExistenciaGee', 'CH6221', '192.168.137.1', '2017-02-18', '11:04:39', 'Actualización'),
(408, 'admin', 'Proxies\\__CG__\\SigigeeBundle\\ExistenciaGee', 'CH6221', '192.168.137.1', '2017-02-18', '11:04:39', 'Actualización'),
(409, 'admin', 'SigigeeBundle\\CertifOperacion', '28CH6221', '192.168.137.1', '2017-02-18', '11:04:39', 'Adición'),
(410, 'admin', 'SigigeeBundle\\RegistroOperacion', '11 CH3356 COPPELIA', '192.168.137.1', '2017-02-18', '11:05:07', 'Actualización'),
(411, 'admin', 'SigigeeBundle\\RegistroOperacion', '11 CH3356 COPPELIA', '192.168.137.1', '2017-02-18', '11:05:29', 'Actualización'),
(412, 'admin', 'Proxies\\__CG__\\SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '11:05:29', 'Actualización'),
(413, 'admin', 'Proxies\\__CG__\\SigigeeBundle\\ExistenciaGee', 'CH3356', '192.168.137.1', '2017-02-18', '11:05:29', 'Actualización'),
(414, 'admin', 'SigigeeBundle\\CertifOperacion', '29CH3356', '192.168.137.1', '2017-02-18', '11:05:29', 'Adición'),
(415, 'admin', 'SigigeeBundle\\RegistroOperacion', '10 CH3046 DIRECCION PROVINCIAL DE EDUCACION', '192.168.137.1', '2017-02-18', '11:05:59', 'Actualización'),
(416, 'admin', 'SigigeeBundle\\RegistroOperacion', '8 CH7556 CARDIOCENTRO WILLIAM SOLER', '192.168.137.1', '2017-02-18', '11:06:22', 'Actualización'),
(417, 'admin', 'SigigeeBundle\\RegistroOperacion', '13 CH9624 SERVAC', '192.168.137.1', '2017-02-18', '11:07:28', 'Adición'),
(418, 'admin', 'SigigeeBundle\\RegistroOperacion', '14 CH6390 FRIGORIFICO CARLOS III', '192.168.137.1', '2017-02-18', '11:08:36', 'Adición'),
(419, 'admin', 'SigigeeBundle\\RegistroOperacion', '15 CH2848 EMPRESA DE CAMIONES NARCISO LOPEZ ROSELLO', '192.168.137.1', '2017-02-18', '11:09:47', 'Adición'),
(420, 'admin', 'SigigeeBundle\\RegistroOperacion', '16 CH7291 INSTITUTO DE DESARROLLO AUTOMOTOR', '192.168.137.1', '2017-02-18', '11:10:46', 'Adición'),
(421, 'admin', 'SigigeeBundle\\CertifOperacion', '30CH5410', '192.168.137.1', '2017-02-18', '11:11:56', 'Adición'),
(422, 'admin', 'SigigeeBundle\\CertifOperacion', '31CH6122', '192.168.137.1', '2017-02-18', '11:12:52', 'Adición'),
(423, 'admin', 'Application\\Sonata\\UserBundle\\User', 'reina', '127.0.0.1', '2017-02-18', '11:24:45', 'Eliminación'),
(424, 'admin', 'Application\\Sonata\\UserBundle\\User', 'pepe', '127.0.0.1', '2017-02-18', '11:24:45', 'Eliminación'),
(425, 'admin', 'Application\\Sonata\\UserBundle\\User', 'regla', '127.0.0.1', '2017-02-18', '11:24:45', 'Eliminación'),
(426, 'admin', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '127.0.0.1', '2017-02-18', '11:27:54', 'Adición'),
(427, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '11:30:16', 'LogOut'),
(428, 'procesadorDatos', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '11:34:11', 'LogIn'),
(429, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '127.0.0.1', '2017-02-18', '11:34:11', 'Actualización');
INSERT INTO `traza` (`id`, `usuario`, `tabla`, `registro`, `ip`, `fecha`, `hora`, `accion`) VALUES
(430, 'procesadorDatos', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '11:36:14', 'LogOut'),
(431, 'procesadorDatos', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '11:36:36', 'LogIn'),
(432, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '127.0.0.1', '2017-02-18', '11:36:36', 'Actualización'),
(433, 'procesadorDatos', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '11:38:13', 'LogOut'),
(434, 'procesadorDatos', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '11:38:49', 'LogIn'),
(435, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '127.0.0.1', '2017-02-18', '11:38:49', 'Actualización'),
(436, 'procesadorDatos', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '11:41:42', 'LogOut'),
(437, 'procesadorDatos', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '11:42:08', 'LogIn'),
(438, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '127.0.0.1', '2017-02-18', '11:42:09', 'Actualización'),
(439, 'procesadorDatos', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '11:43:21', 'LogOut'),
(440, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '11:43:44', 'LogIn'),
(441, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-02-18', '11:43:44', 'Actualización'),
(442, 'admin', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '127.0.0.1', '2017-02-18', '11:45:20', 'Actualización'),
(443, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '11:45:49', 'LogOut'),
(444, 'procesadorDatos', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '11:46:11', 'LogIn'),
(445, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '127.0.0.1', '2017-02-18', '11:46:11', 'Actualización'),
(446, 'procesadorDatos', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '11:51:08', 'LogIn'),
(447, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '127.0.0.1', '2017-02-18', '11:51:09', 'Actualización'),
(448, 'procesadorDatos', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '11:53:16', 'LogOut'),
(449, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '11:53:40', 'LogIn'),
(450, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-02-18', '11:53:40', 'Actualización'),
(451, 'admin', 'Sistema', 'LogOut exitoso', '192.168.137.1', '2017-02-18', '11:55:42', 'LogOut'),
(452, 'procesadorDatos', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-02-18', '11:56:11', 'LogIn'),
(453, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '192.168.137.1', '2017-02-18', '11:56:11', 'Actualización'),
(454, 'procesadorDatos', 'Sistema', 'LogOut exitoso', '192.168.137.1', '2017-02-18', '11:59:54', 'LogOut'),
(455, 'procesadorDatos', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-02-18', '12:00:06', 'LogIn'),
(456, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '192.168.137.1', '2017-02-18', '12:00:07', 'Actualización'),
(457, 'procesadorDatos', 'Sistema', 'LogOut exitoso', '192.168.137.1', '2017-02-18', '12:05:19', 'LogOut'),
(458, 'procesadorDatos', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-02-18', '12:05:29', 'LogIn'),
(459, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '192.168.137.1', '2017-02-18', '12:05:29', 'Actualización'),
(460, 'admin', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '127.0.0.1', '2017-02-18', '12:06:18', 'Actualización'),
(461, 'procesadorDatos', 'Sistema', 'LogOut exitoso', '192.168.137.1', '2017-02-18', '12:06:46', 'LogOut'),
(462, 'procesadorDatos', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-02-18', '12:06:56', 'LogIn'),
(463, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '192.168.137.1', '2017-02-18', '12:06:56', 'Actualización'),
(464, 'procesadorDatos', 'Sistema', 'LogOut exitoso', '192.168.137.1', '2017-02-18', '12:09:12', 'LogOut'),
(465, 'procesadorDatos', 'Sistema', 'Login exitoso', '192.168.137.1', '2017-02-18', '12:09:23', 'LogIn'),
(466, 'procesadorDatos', 'Application\\Sonata\\UserBundle\\User', 'procesadorDatos', '192.168.137.1', '2017-02-18', '12:09:24', 'Actualización'),
(467, 'admin', 'Application\\Sonata\\UserBundle\\User', 'operadora', '127.0.0.1', '2017-02-18', '12:11:46', 'Adición'),
(468, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '12:18:03', 'LogOut'),
(469, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '13:20:33', 'LogIn'),
(470, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-02-18', '13:20:33', 'Actualización'),
(471, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '13:21:35', 'LogOut'),
(472, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '13:21:56', 'LogIn'),
(473, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '13:25:09', 'LogOut'),
(474, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '13:48:18', 'LogIn'),
(475, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '13:48:37', 'LogOut'),
(476, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '13:49:59', 'LogIn'),
(477, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '13:50:45', 'LogOut'),
(478, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '13:51:05', 'LogIn'),
(479, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '13:52:29', 'LogOut'),
(480, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '13:52:47', 'LogIn'),
(481, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '13:53:14', 'LogOut'),
(482, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '14:15:02', 'LogIn'),
(483, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-02-18', '14:15:18', 'LogOut'),
(484, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '14:15:37', 'LogIn'),
(485, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-18', '14:26:58', 'LogIn'),
(486, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-02-21', '20:50:41', 'LogIn'),
(487, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-03-13', '22:02:37', 'LogIn'),
(488, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-03-16', '09:49:15', 'LogOut'),
(489, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-03-16', '10:01:50', 'LogIn'),
(490, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-03-16', '10:02:04', 'LogIn'),
(491, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-05-03', '11:19:04', 'LogIn'),
(492, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-05-03', '11:49:56', 'LogOut'),
(493, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-05-03', '11:50:43', 'LogIn'),
(494, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-05-03', '12:00:52', 'LogOut'),
(495, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-05-03', '12:18:47', 'LogIn'),
(496, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-05-04', '10:06:50', 'LogIn'),
(497, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-05-04', '11:50:37', 'LogIn'),
(498, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-05-15', '16:07:18', 'LogIn'),
(499, 'admin', 'SigigeeBundle\\EstadoGee', 'Baja Cobertura', '127.0.0.1', '2017-05-25', '12:39:07', 'Actualización'),
(500, 'admin', 'SigigeeBundle\\SolicCombLlenadoInicial', '0.534 SERVAC', '127.0.0.1', '2017-05-25', '13:52:16', 'Actualización'),
(501, 'admin', 'SigigeeBundle\\ExistenciaGee', 'CH9020', '127.0.0.1', '2017-05-27', '02:11:40', 'Actualización'),
(502, 'admin', 'Sistema', 'LogOut exitoso', '127.0.0.1', '2017-05-30', '18:49:26', 'LogOut'),
(503, 'admin', 'Sistema', 'Login exitoso', '127.0.0.1', '2017-05-30', '18:56:24', 'LogIn'),
(504, 'admin', 'Application\\Sonata\\UserBundle\\User', 'admin', '127.0.0.1', '2017-05-30', '18:56:24', 'Actualización');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asignacion_comb`
--
ALTER TABLE `asignacion_comb`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_15CD419060197D6F` (`gee_id`),
  ADD KEY `IDX_15CD41904E7121AF` (`provincia_id`),
  ADD KEY `IDX_15CD41901A950FD2` (`tipo_distribucion_id`),
  ADD KEY `IDX_15CD41906CA204EF` (`entidad_id`);

--
-- Indices de la tabla `certif_operacion`
--
ALTER TABLE `certif_operacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_8B04E27060197D6F` (`gee_id`),
  ADD KEY `IDX_8B04E27058BC1BE0` (`municipio_id`),
  ADD KEY `IDX_8B04E270298137A7` (`centro_id`),
  ADD KEY `IDX_8B04E27081EF0041` (`marca_id`),
  ADD KEY `IDX_8B04E270D10A2BC3` (`kva_voltaje_salida_id`),
  ADD KEY `IDX_8B04E270D6E942AE` (`estado_certificacion_id`);

--
-- Indices de la tabla `concepto_aprob_comb`
--
ALTER TABLE `concepto_aprob_comb`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_CAB09AD43A909126` (`nombre`);

--
-- Indices de la tabla `entidad`
--
ALTER TABLE `entidad`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_4587B0CBD30B49A2` (`entidad_superior_id`),
  ADD KEY `IDX_4587B0CBCC377906` (`ministerio_id`),
  ADD KEY `IDX_4587B0CB58BC1BE0` (`municipio_id`),
  ADD KEY `IDX_4587B0CB4E7121AF` (`provincia_id`),
  ADD KEY `IDX_4587B0CBB77634D2` (`moneda_id`);

--
-- Indices de la tabla `estado_aprobacion`
--
ALTER TABLE `estado_aprobacion`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_C0AB93B43A909126` (`nombre`);

--
-- Indices de la tabla `estado_certificacion`
--
ALTER TABLE `estado_certificacion`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_C29F3FD73A909126` (`nombre`);

--
-- Indices de la tabla `estado_gee`
--
ALTER TABLE `estado_gee`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_6B12E5DD3A909126` (`nombre`);

--
-- Indices de la tabla `estado_operacion`
--
ALTER TABLE `estado_operacion`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_A05A13D3A909126` (`nombre`);

--
-- Indices de la tabla `estado_tecnico`
--
ALTER TABLE `estado_tecnico`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_2E9323D13A909126` (`nombre`);

--
-- Indices de la tabla `existencia_gee`
--
ALTER TABLE `existencia_gee`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_D6D98F2BF543ED4` (`noInventario`),
  ADD KEY `IDX_D6D98F2F5A08B77` (`tipo_gee_id`),
  ADD KEY `IDX_D6D98F26CA204EF` (`entidad_id`),
  ADD KEY `IDX_D6D98F29F5A440B` (`estado_id`),
  ADD KEY `IDX_D6D98F2CCCF7FF5` (`distribucion_id`);

--
-- Indices de la tabla `fos_user_group`
--
ALTER TABLE `fos_user_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_583D1F3E5E237E06` (`name`);

--
-- Indices de la tabla `fos_user_user`
--
ALTER TABLE `fos_user_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_C560D76192FC23A8` (`username_canonical`),
  ADD UNIQUE KEY `UNIQ_C560D761A0D96FBF` (`email_canonical`);

--
-- Indices de la tabla `fos_user_user_group`
--
ALTER TABLE `fos_user_user_group`
  ADD PRIMARY KEY (`user_id`,`group_id`),
  ADD KEY `IDX_B3C77447A76ED395` (`user_id`),
  ADD KEY `IDX_B3C77447FE54D947` (`group_id`);

--
-- Indices de la tabla `ministerio`
--
ALTER TABLE `ministerio`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `municipio`
--
ALTER TABLE `municipio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FE98F5E04E7121AF` (`provincia_id`);

--
-- Indices de la tabla `nom_gee`
--
ALTER TABLE `nom_gee`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_25412ED1C27DAA80` (`corriente_salida_um_id`),
  ADD KEY `IDX_25412ED19DBAB4E7` (`potencia_salida_um_id`),
  ADD KEY `IDX_25412ED1EA4F42C1` (`largo_um_id`),
  ADD KEY `IDX_25412ED1B24B10D5` (`ancho_um_id`),
  ADD KEY `IDX_25412ED1AEBA308F` (`alto_um_id`),
  ADD KEY `IDX_25412ED1C0B0651B` (`peso_um_id`),
  ADD KEY `IDX_25412ED181EF0041` (`marca_id`),
  ADD KEY `IDX_25412ED180D58D71` (`motor_id`),
  ADD KEY `IDX_25412ED1CCC381E3` (`generador_id`),
  ADD KEY `IDX_25412ED1F1FAA8D0` (`voltaje_salida_id`);

--
-- Indices de la tabla `nom_generador`
--
ALTER TABLE `nom_generador`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nom_marca`
--
ALTER TABLE `nom_marca`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nom_moneda`
--
ALTER TABLE `nom_moneda`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_30C4B47A3A909126` (`nombre`);

--
-- Indices de la tabla `nom_motor`
--
ALTER TABLE `nom_motor`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nom_unidad_medida`
--
ALTER TABLE `nom_unidad_medida`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nom_voltaje`
--
ALTER TABLE `nom_voltaje`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_4DB996422E003F4` (`unidad_medida_id`);

--
-- Indices de la tabla `provincia`
--
ALTER TABLE `provincia`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `registro_operacion`
--
ALTER TABLE `registro_operacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_415F514360197D6F` (`gee_id`),
  ADD KEY `IDX_415F5143A9276E6C` (`tipo_id`),
  ADD KEY `IDX_415F51438D84CADE` (`estado_operacion_id`);

--
-- Indices de la tabla `resumen_certificacion`
--
ALTER TABLE `resumen_certificacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_2D9E8EA060197D6F` (`gee_id`),
  ADD KEY `IDX_2D9E8EA058BC1BE0` (`municipio_id`),
  ADD KEY `IDX_2D9E8EA0298137A7` (`centro_id`),
  ADD KEY `IDX_2D9E8EA081EF0041` (`marca_id`);

--
-- Indices de la tabla `solic_comb_llenado_inicial`
--
ALTER TABLE `solic_comb_llenado_inicial`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_A404A65260197D6F` (`gee_id`),
  ADD KEY `IDX_A404A652927C8F01` (`aprobado_id`),
  ADD KEY `IDX_A404A652CCCF7FF5` (`distribucion_id`),
  ADD KEY `IDX_A404A652D0990F08` (`destino_final_id`);

--
-- Indices de la tabla `tipo_distribucion`
--
ALTER TABLE `tipo_distribucion`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_DAD506A7801B7D4B` (`sigla`),
  ADD UNIQUE KEY `UNIQ_DAD506A73A909126` (`nombre`);

--
-- Indices de la tabla `tipo_operacion`
--
ALTER TABLE `tipo_operacion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `traza`
--
ALTER TABLE `traza`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asignacion_comb`
--
ALTER TABLE `asignacion_comb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT de la tabla `certif_operacion`
--
ALTER TABLE `certif_operacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT de la tabla `concepto_aprob_comb`
--
ALTER TABLE `concepto_aprob_comb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `entidad`
--
ALTER TABLE `entidad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT de la tabla `estado_aprobacion`
--
ALTER TABLE `estado_aprobacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `estado_certificacion`
--
ALTER TABLE `estado_certificacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `estado_gee`
--
ALTER TABLE `estado_gee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `estado_operacion`
--
ALTER TABLE `estado_operacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `estado_tecnico`
--
ALTER TABLE `estado_tecnico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `existencia_gee`
--
ALTER TABLE `existencia_gee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT de la tabla `fos_user_group`
--
ALTER TABLE `fos_user_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `fos_user_user`
--
ALTER TABLE `fos_user_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT de la tabla `ministerio`
--
ALTER TABLE `ministerio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT de la tabla `municipio`
--
ALTER TABLE `municipio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de la tabla `nom_gee`
--
ALTER TABLE `nom_gee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `nom_generador`
--
ALTER TABLE `nom_generador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `nom_marca`
--
ALTER TABLE `nom_marca`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT de la tabla `nom_moneda`
--
ALTER TABLE `nom_moneda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `nom_motor`
--
ALTER TABLE `nom_motor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `nom_unidad_medida`
--
ALTER TABLE `nom_unidad_medida`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `nom_voltaje`
--
ALTER TABLE `nom_voltaje`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de la tabla `provincia`
--
ALTER TABLE `provincia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT de la tabla `registro_operacion`
--
ALTER TABLE `registro_operacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT de la tabla `resumen_certificacion`
--
ALTER TABLE `resumen_certificacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `solic_comb_llenado_inicial`
--
ALTER TABLE `solic_comb_llenado_inicial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT de la tabla `tipo_distribucion`
--
ALTER TABLE `tipo_distribucion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tipo_operacion`
--
ALTER TABLE `tipo_operacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `traza`
--
ALTER TABLE `traza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=505;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `asignacion_comb`
--
ALTER TABLE `asignacion_comb`
  ADD CONSTRAINT `FK_15CD41901A950FD2` FOREIGN KEY (`tipo_distribucion_id`) REFERENCES `tipo_distribucion` (`id`),
  ADD CONSTRAINT `FK_15CD41904E7121AF` FOREIGN KEY (`provincia_id`) REFERENCES `provincia` (`id`),
  ADD CONSTRAINT `FK_15CD419060197D6F` FOREIGN KEY (`gee_id`) REFERENCES `existencia_gee` (`id`),
  ADD CONSTRAINT `FK_15CD41906CA204EF` FOREIGN KEY (`entidad_id`) REFERENCES `entidad` (`id`);

--
-- Filtros para la tabla `certif_operacion`
--
ALTER TABLE `certif_operacion`
  ADD CONSTRAINT `FK_8B04E270298137A7` FOREIGN KEY (`centro_id`) REFERENCES `entidad` (`id`),
  ADD CONSTRAINT `FK_8B04E27058BC1BE0` FOREIGN KEY (`municipio_id`) REFERENCES `municipio` (`id`),
  ADD CONSTRAINT `FK_8B04E27060197D6F` FOREIGN KEY (`gee_id`) REFERENCES `existencia_gee` (`id`),
  ADD CONSTRAINT `FK_8B04E27081EF0041` FOREIGN KEY (`marca_id`) REFERENCES `nom_marca` (`id`),
  ADD CONSTRAINT `FK_8B04E270D10A2BC3` FOREIGN KEY (`kva_voltaje_salida_id`) REFERENCES `nom_voltaje` (`id`),
  ADD CONSTRAINT `FK_8B04E270D6E942AE` FOREIGN KEY (`estado_certificacion_id`) REFERENCES `estado_certificacion` (`id`);

--
-- Filtros para la tabla `entidad`
--
ALTER TABLE `entidad`
  ADD CONSTRAINT `FK_4587B0CB4E7121AF` FOREIGN KEY (`provincia_id`) REFERENCES `provincia` (`id`),
  ADD CONSTRAINT `FK_4587B0CB58BC1BE0` FOREIGN KEY (`municipio_id`) REFERENCES `municipio` (`id`),
  ADD CONSTRAINT `FK_4587B0CBB77634D2` FOREIGN KEY (`moneda_id`) REFERENCES `nom_moneda` (`id`),
  ADD CONSTRAINT `FK_4587B0CBCC377906` FOREIGN KEY (`ministerio_id`) REFERENCES `ministerio` (`id`),
  ADD CONSTRAINT `FK_4587B0CBD30B49A2` FOREIGN KEY (`entidad_superior_id`) REFERENCES `entidad` (`id`);

--
-- Filtros para la tabla `existencia_gee`
--
ALTER TABLE `existencia_gee`
  ADD CONSTRAINT `FK_D6D98F26CA204EF` FOREIGN KEY (`entidad_id`) REFERENCES `entidad` (`id`),
  ADD CONSTRAINT `FK_D6D98F29F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `estado_gee` (`id`),
  ADD CONSTRAINT `FK_D6D98F2CCCF7FF5` FOREIGN KEY (`distribucion_id`) REFERENCES `tipo_distribucion` (`id`),
  ADD CONSTRAINT `FK_D6D98F2F5A08B77` FOREIGN KEY (`tipo_gee_id`) REFERENCES `nom_gee` (`id`);

--
-- Filtros para la tabla `fos_user_user_group`
--
ALTER TABLE `fos_user_user_group`
  ADD CONSTRAINT `FK_B3C77447A76ED395` FOREIGN KEY (`user_id`) REFERENCES `fos_user_user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_B3C77447FE54D947` FOREIGN KEY (`group_id`) REFERENCES `fos_user_group` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `municipio`
--
ALTER TABLE `municipio`
  ADD CONSTRAINT `FK_FE98F5E04E7121AF` FOREIGN KEY (`provincia_id`) REFERENCES `provincia` (`id`);

--
-- Filtros para la tabla `nom_gee`
--
ALTER TABLE `nom_gee`
  ADD CONSTRAINT `FK_25412ED180D58D71` FOREIGN KEY (`motor_id`) REFERENCES `nom_motor` (`id`),
  ADD CONSTRAINT `FK_25412ED181EF0041` FOREIGN KEY (`marca_id`) REFERENCES `nom_marca` (`id`),
  ADD CONSTRAINT `FK_25412ED19DBAB4E7` FOREIGN KEY (`potencia_salida_um_id`) REFERENCES `nom_unidad_medida` (`id`),
  ADD CONSTRAINT `FK_25412ED1AEBA308F` FOREIGN KEY (`alto_um_id`) REFERENCES `nom_unidad_medida` (`id`),
  ADD CONSTRAINT `FK_25412ED1B24B10D5` FOREIGN KEY (`ancho_um_id`) REFERENCES `nom_unidad_medida` (`id`),
  ADD CONSTRAINT `FK_25412ED1C0B0651B` FOREIGN KEY (`peso_um_id`) REFERENCES `nom_unidad_medida` (`id`),
  ADD CONSTRAINT `FK_25412ED1C27DAA80` FOREIGN KEY (`corriente_salida_um_id`) REFERENCES `nom_unidad_medida` (`id`),
  ADD CONSTRAINT `FK_25412ED1CCC381E3` FOREIGN KEY (`generador_id`) REFERENCES `nom_generador` (`id`),
  ADD CONSTRAINT `FK_25412ED1EA4F42C1` FOREIGN KEY (`largo_um_id`) REFERENCES `nom_unidad_medida` (`id`),
  ADD CONSTRAINT `FK_25412ED1F1FAA8D0` FOREIGN KEY (`voltaje_salida_id`) REFERENCES `nom_voltaje` (`id`);

--
-- Filtros para la tabla `nom_voltaje`
--
ALTER TABLE `nom_voltaje`
  ADD CONSTRAINT `FK_4DB996422E003F4` FOREIGN KEY (`unidad_medida_id`) REFERENCES `nom_unidad_medida` (`id`);

--
-- Filtros para la tabla `registro_operacion`
--
ALTER TABLE `registro_operacion`
  ADD CONSTRAINT `FK_415F514360197D6F` FOREIGN KEY (`gee_id`) REFERENCES `existencia_gee` (`id`),
  ADD CONSTRAINT `FK_415F51438D84CADE` FOREIGN KEY (`estado_operacion_id`) REFERENCES `estado_operacion` (`id`),
  ADD CONSTRAINT `FK_415F5143A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `tipo_operacion` (`id`);

--
-- Filtros para la tabla `resumen_certificacion`
--
ALTER TABLE `resumen_certificacion`
  ADD CONSTRAINT `FK_2D9E8EA0298137A7` FOREIGN KEY (`centro_id`) REFERENCES `entidad` (`id`),
  ADD CONSTRAINT `FK_2D9E8EA058BC1BE0` FOREIGN KEY (`municipio_id`) REFERENCES `municipio` (`id`),
  ADD CONSTRAINT `FK_2D9E8EA060197D6F` FOREIGN KEY (`gee_id`) REFERENCES `existencia_gee` (`id`),
  ADD CONSTRAINT `FK_2D9E8EA081EF0041` FOREIGN KEY (`marca_id`) REFERENCES `nom_marca` (`id`);

--
-- Filtros para la tabla `solic_comb_llenado_inicial`
--
ALTER TABLE `solic_comb_llenado_inicial`
  ADD CONSTRAINT `FK_A404A65260197D6F` FOREIGN KEY (`gee_id`) REFERENCES `existencia_gee` (`id`),
  ADD CONSTRAINT `FK_A404A652927C8F01` FOREIGN KEY (`aprobado_id`) REFERENCES `estado_aprobacion` (`id`),
  ADD CONSTRAINT `FK_A404A652CCCF7FF5` FOREIGN KEY (`distribucion_id`) REFERENCES `tipo_distribucion` (`id`),
  ADD CONSTRAINT `FK_A404A652D0990F08` FOREIGN KEY (`destino_final_id`) REFERENCES `entidad` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
